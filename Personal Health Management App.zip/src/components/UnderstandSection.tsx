import { useState } from 'react';
import { Award, ArrowLeft, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface ArticleContent {
  level: number;
  content: string;
}

interface Article {
  id: string;
  title: string;
  summary: string;
  imageUrl: string;
  levels: ArticleContent[];
  points: number;
}

const articles: Article[] = [
  {
    id: '1',
    title: 'Understanding Food Triggers',
    summary: 'Certain foods can trigger digestive symptoms. Learning to identify your personal triggers is key to managing your health.',
    imageUrl: 'https://images.unsplash.com/photo-1758738880738-8f662ac47e4f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoZWFsdGh5JTIwZm9vZCUyMGluZ3JlZGllbnRzJTIwdmVnZXRhYmxlc3xlbnwxfHx8fDE3NjQ4MDAzMDR8MA&ixlib=rb-4.1.0&q=80&w=1080',
    levels: [
      {
        level: 1,
        content: 'Food triggers vary from person to person, but common culprits include dairy, gluten, high-fat foods, and caffeine. Your body may react to these foods with inflammation, increased gut motility, or other responses.'
      },
      {
        level: 2,
        content: 'When you consume a trigger food, your immune system may perceive it as a threat. This leads to the release of inflammatory markers like cytokines and histamines. In the gut, this can manifest as bloating, cramping, or changes in bowel movements. Some people have immediate reactions, while others experience delayed symptoms up to 72 hours later.'
      },
      {
        level: 3,
        content: 'The key to identifying your triggers is systematic tracking. Start by keeping a detailed food and symptom diary for at least 2 weeks. Note what you eat, when you eat it, and any symptoms that follow. Look for patterns—if you notice symptoms consistently appear 2-4 hours after consuming dairy, that\'s a strong signal.'
      },
      {
        level: 4,
        content: 'Once you\'ve identified potential triggers, try an elimination diet. Remove one suspected trigger at a time for 2-3 weeks, then slowly reintroduce it. This helps you understand which foods truly affect you. Remember to reintroduce foods one at a time with at least 3 days between each new food. Keep tracking your symptoms throughout this process. Many people find that working with a registered dietitian can make this process more effective and ensure you maintain proper nutrition.'
      }
    ],
    points: 5
  },
  {
    id: '2',
    title: 'The Gut-Brain Connection',
    summary: 'Stress and emotions directly impact your digestive system. Your gut and brain communicate constantly through the vagus nerve.',
    imageUrl: 'https://images.unsplash.com/photo-1655970580622-4a547789c850?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpdGF0aW9uJTIwYnJhaW4lMjB3ZWxsbmVzc3xlbnwxfHx8fDE3NjQ4MDAzMDV8MA&ixlib=rb-4.1.0&q=80&w=1080',
    levels: [
      {
        level: 1,
        content: 'The gut-brain axis is a bidirectional communication system. When you\'re stressed, your brain sends signals that can change gut motility, increase inflammation, and alter the balance of gut bacteria. This is why anxiety often leads to digestive symptoms.'
      },
      {
        level: 2,
        content: 'Your gut contains over 100 million neurons—more than your spinal cord! This "second brain" is called the enteric nervous system. It produces 95% of your body\'s serotonin, the neurotransmitter that regulates mood. When you\'re anxious or stressed, your brain releases cortisol and other stress hormones that directly affect gut function.'
      },
      {
        level: 3,
        content: 'Stress can slow or speed up gut motility, depending on the individual. It can also make your gut more sensitive to pain and discomfort. Additionally, chronic stress disrupts the balance of good and bad bacteria in your microbiome, which can worsen digestive symptoms and even affect your mental health in a feedback loop.'
      },
      {
        level: 4,
        content: 'Managing the gut-brain connection requires a holistic approach. Practice stress-reduction techniques like deep breathing (5 minutes before meals), progressive muscle relaxation, or meditation. Even a brief 5-minute meditation when you feel symptoms coming on can help calm your nervous system. Regular exercise, adequate sleep (7-9 hours), and staying socially connected also support both gut and mental health. Consider cognitive behavioral therapy (CBT) or gut-directed hypnotherapy, which have been shown to reduce digestive symptoms in clinical studies.'
      }
    ],
    points: 5
  },
  {
    id: '3',
    title: 'Building Consistent Routines',
    summary: 'Your digestive system loves predictability. Eating, sleeping, and exercising at regular times can improve symptoms.',
    imageUrl: 'https://images.unsplash.com/photo-1506784983877-45594efa4cbe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb3JuaW5nJTIwcm91dGluZSUyMGNhbGVuZGFyfGVufDF8fHx8MTc2NDgwMDMwNXww&ixlib=rb-4.1.0&q=80&w=1080',
    levels: [
      {
        level: 1,
        content: 'Your gut has its own circadian rhythm. Eating meals at consistent times helps regulate digestive hormones, enzyme production, and gut motility. Similarly, regular sleep patterns support the gut microbiome and reduce inflammation.'
      },
      {
        level: 2,
        content: 'When you eat at the same times each day, your body learns to prepare for digestion. Your stomach produces acid, your pancreas releases enzymes, and your intestines prepare for nutrient absorption—all before food arrives. This synchronized process makes digestion more efficient and comfortable.'
      },
      {
        level: 3,
        content: 'Irregular eating patterns confuse your digestive system. Late-night eating, for example, can disrupt the natural cleansing waves (called migrating motor complexes) that sweep through your intestines during fasting periods. These waves help prevent bacterial overgrowth and keep things moving smoothly. Aim to eat your last meal 3-4 hours before bedtime.'
      },
      {
        level: 4,
        content: 'Create a daily routine that supports your gut health. Wake up and go to bed at the same time each day, even on weekends. Set regular meal times—try to eat within the same 30-minute window each day. Schedule time for gentle exercise, like a 20-30 minute walk after meals, which can help with digestion and stress management. Many people find it helpful to set phone reminders for meals and bedtime until these routines become automatic. Track how you feel as you build these habits—most people notice improvements within 2-3 weeks of consistent routines.'
      }
    ],
    points: 5
  }
];

function ArticleModal({ article, onClose }: { article: Article; onClose: () => void }) {
  const [currentLevel, setCurrentLevel] = useState(0);
  const [showCelebration, setShowCelebration] = useState(false);
  const [direction, setDirection] = useState(0);

  const isIntro = currentLevel === -1;
  const isComplete = currentLevel >= article.levels.length;
  const totalSteps = article.levels.length + 1; // +1 for intro

  const handleLearnMore = () => {
    setDirection(1);
    if (currentLevel < article.levels.length) {
      setCurrentLevel(currentLevel + 1);
    }
  };

  const handleBack = () => {
    setDirection(-1);
    if (currentLevel > -1) {
      setCurrentLevel(currentLevel - 1);
    } else {
      onClose();
    }
  };

  const handleDone = () => {
    setShowCelebration(true);
    setTimeout(() => {
      onClose();
    }, 2000);
  };

  const variants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 300 : -300,
      opacity: 0,
    }),
    center: {
      x: 0,
      opacity: 1,
    },
    exit: (direction: number) => ({
      x: direction > 0 ? -300 : 300,
      opacity: 0,
    }),
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#FBF7F4] overflow-hidden">
      <div className="h-full flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-6">
          <button
            onClick={handleBack}
            className="p-2 -ml-2 hover:bg-white/50 rounded-full transition-colors"
          >
            <ArrowLeft className="w-6 h-6 text-[#3D2F24]" />
          </button>
          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-white rounded-full shadow-sm">
            <Award className="w-4 h-4 text-[#D9532E]" />
            <span className="text-sm text-[#3D2F24]">{article.points} pts</span>
          </div>
        </div>

        {/* Progress Dots */}
        <div className="flex justify-center gap-2 mb-6">
          <div
            className={`w-2 h-2 rounded-full transition-all ${
              currentLevel === -1 ? 'bg-[#D9532E] w-6' : 'bg-[#E5D5C5]'
            }`}
          />
          {article.levels.map((_, index) => (
            <div
              key={index}
              className={`w-2 h-2 rounded-full transition-all ${
                currentLevel === index ? 'bg-[#D9532E] w-6' : 'bg-[#E5D5C5]'
              }`}
            />
          ))}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-hidden px-6 pb-32">
          <AnimatePresence mode="wait" custom={direction}>
            {currentLevel === -1 && (
              <motion.div
                key="intro"
                custom={direction}
                variants={variants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ duration: 0.3 }}
                className="max-w-lg mx-auto h-full flex flex-col justify-center"
              >
                <h1 className="text-[#2B2317] mb-4 text-center">{article.title}</h1>
                <div className="bg-gradient-to-br from-[#FFF3EB] to-[#FFE8D9] rounded-3xl p-8 border border-[#F5D5C0] text-center">
                  <p className="text-[#2B2317] leading-relaxed text-lg">
                    {article.summary}
                  </p>
                </div>
              </motion.div>
            )}

            {currentLevel >= 0 && currentLevel < article.levels.length && (
              <motion.div
                key={currentLevel}
                custom={direction}
                variants={variants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ duration: 0.3 }}
                className="max-w-lg mx-auto h-full flex flex-col justify-center"
              >
                <div className="bg-white rounded-3xl p-8 shadow-sm border border-[#E5D5C5]">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#E8734E] to-[#D9532E] flex items-center justify-center flex-shrink-0">
                      <span className="text-white">{article.levels[currentLevel].level}</span>
                    </div>
                    <h3 className="text-[#3D2F24]">
                      {article.levels[currentLevel].level === 1 && 'The Basics'}
                      {article.levels[currentLevel].level === 2 && 'Going Deeper'}
                      {article.levels[currentLevel].level === 3 && 'The Science'}
                      {article.levels[currentLevel].level === 4 && 'Taking Action'}
                    </h3>
                  </div>
                  <p className="text-[#2B2317] leading-relaxed text-lg">
                    {article.levels[currentLevel].content}
                  </p>
                </div>
              </motion.div>
            )}

            {isComplete && !showCelebration && (
              <motion.div
                key="complete"
                custom={direction}
                variants={variants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ duration: 0.3 }}
                className="max-w-lg mx-auto h-full flex flex-col justify-center"
              >
                <div className="bg-gradient-to-br from-[#D4EDD5] to-[#E5F4E6] rounded-3xl p-8 border border-[#B8D9B9] text-center">
                  <div className="w-16 h-16 rounded-full bg-[#5D8A5E] flex items-center justify-center mx-auto mb-4">
                    <Award className="w-8 h-8 text-white" />
                  </div>
                  <h2 className="text-[#2B2317] mb-3">Great work!</h2>
                  <p className="text-[#4A7A4B] mb-6">
                    You've completed this article
                  </p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Bottom Button */}
        <div className="absolute bottom-0 left-0 right-0 px-6 pb-8 pt-4 bg-gradient-to-t from-[#FBF7F4] via-[#FBF7F4] to-transparent">
          {!isComplete && (
            <button
              onClick={handleLearnMore}
              className="w-full py-4 bg-gradient-to-r from-[#E8734E] to-[#D9532E] text-white rounded-full shadow-lg hover:shadow-xl transition-all hover:scale-[1.02]"
            >
              Learn More
            </button>
          )}
          {isComplete && !showCelebration && (
            <button
              onClick={handleDone}
              className="w-full py-4 bg-gradient-to-r from-[#5D8A5E] to-[#4A7A4B] text-white rounded-full shadow-lg hover:shadow-xl transition-all hover:scale-[1.02]"
            >
              Done
            </button>
          )}
        </div>
      </div>

      {/* Celebration Animation */}
      <AnimatePresence>
        {showCelebration && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 flex items-center justify-center bg-[#FBF7F4]/95 z-50"
          >
            <motion.div
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ type: 'spring', duration: 0.6 }}
              className="text-center"
            >
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: [0, 1.2, 1] }}
                transition={{ delay: 0.2, duration: 0.5 }}
                className="w-32 h-32 rounded-full bg-gradient-to-br from-[#E8734E] to-[#D9532E] flex items-center justify-center mx-auto mb-4 shadow-2xl"
              >
                <Award className="w-16 h-16 text-white" />
              </motion.div>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
              >
                <h2 className="text-[#2B2317] mb-2">+{article.points} points!</h2>
                <p className="text-[#6B5A4C]">Amazing progress</p>
              </motion.div>
              
              {/* Confetti particles */}
              {[...Array(12)].map((_, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 1, scale: 0, x: 0, y: 0 }}
                  animate={{
                    opacity: [1, 1, 0],
                    scale: [0, 1, 0.5],
                    x: Math.cos((i * Math.PI * 2) / 12) * 150,
                    y: Math.sin((i * Math.PI * 2) / 12) * 150,
                  }}
                  transition={{ delay: 0.3, duration: 1 }}
                  className="absolute top-1/2 left-1/2 w-3 h-3 rounded-full"
                  style={{
                    backgroundColor: ['#E8734E', '#D9532E', '#5D8A5E', '#D4EDD5'][i % 4],
                  }}
                />
              ))}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function ArticleCard({ article, onClick }: { article: Article; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="w-full bg-white rounded-3xl overflow-hidden shadow-sm border border-[#E5D5C5] mb-3 text-left hover:shadow-md transition-all hover:scale-[1.01]"
    >
      {/* Article Image */}
      <div className="relative w-full aspect-[2/1] overflow-hidden">
        <ImageWithFallback
          src={article.imageUrl}
          alt={article.title}
          className="w-full h-full object-cover"
        />
        {/* Points badge on image */}
        <div className="absolute top-3 right-3 flex items-center gap-1 px-3 py-1.5 bg-white/90 backdrop-blur-sm rounded-full shadow-sm">
          <Award className="w-3.5 h-3.5 text-[#D9532E]" />
          <span className="text-xs text-[#3D2F24]">{article.points} pts</span>
        </div>
      </div>
      
      {/* Article Content */}
      <div className="p-5">
        <h4 className="text-[#2B2317] mb-2">{article.title}</h4>
        <p className="text-sm text-[#6B5A4C] leading-relaxed mb-3">
          {article.summary}
        </p>
        <div className="text-sm text-[#D9532E]">
          Tap to learn more →
        </div>
      </div>
    </button>
  );
}

export function UnderstandSection() {
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);

  return (
    <>
      <section className="px-6 py-4 pb-8">
        <h3 className="text-[#3D2F24] mb-3 px-1">Understand</h3>
        <div>
          {articles.map((article) => (
            <ArticleCard
              key={article.id}
              article={article}
              onClick={() => setSelectedArticle(article)}
            />
          ))}
        </div>
      </section>

      {selectedArticle && (
        <ArticleModal
          article={selectedArticle}
          onClose={() => setSelectedArticle(null)}
        />
      )}
    </>
  );
}