import { useState } from 'react';
import { 
  Sparkles, 
  TrendingUp, 
  TrendingDown, 
  Brain, 
  Users, 
  Flame, 
  ArrowRight,
  X,
  ChevronRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface TrendPoint {
  day: string;
  value: number;
  label: string;
}

interface BubbleData {
  day: string;
  sleep: number;
  symptom: number;
}

function InsightModal({ onClose }: { onClose: () => void }) {
  const trendData: TrendPoint[] = [
    { day: 'Mon', value: 7, label: 'Mon' },
    { day: 'Tue', value: 6, label: 'Tue' },
    { day: 'Wed', value: 5, label: 'Wed' },
    { day: 'Thu', value: 4, label: 'Thu' },
    { day: 'Fri', value: 4, label: 'Fri' },
    { day: 'Sat', value: 3, label: 'Sat' },
    { day: 'Sun', value: 2, label: 'Sun' }
  ];

  // Calculate path for smooth curve
  const maxValue = 10;
  const width = 320;
  const height = 200;
  const padding = 40;
  
  const points = trendData.map((point, index) => ({
    x: padding + (index * (width - 2 * padding) / (trendData.length - 1)),
    y: height - padding - ((point.value / maxValue) * (height - 2 * padding))
  }));

  // Create smooth curve using quadratic bezier
  const pathD = points.reduce((path, point, index) => {
    if (index === 0) {
      return `M ${point.x},${point.y}`;
    }
    const prevPoint = points[index - 1];
    const midX = (prevPoint.x + point.x) / 2;
    return `${path} Q ${prevPoint.x},${point.y} ${midX},${point.y} Q ${point.x},${point.y} ${point.x},${point.y}`;
  }, '');

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-black/20 flex items-center justify-center p-6"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        onClick={(e) => e.stopPropagation()}
        className="bg-[#FBF7F4] rounded-3xl p-6 w-full max-w-md shadow-2xl"
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#D4EDD5] to-[#B8D9B9] flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-[#5D8A5E]" />
            </div>
            <div>
              <h3 className="text-[#2B2317]">Your Trend Story</h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/50 rounded-full transition-colors"
          >
            <X className="w-5 h-5 text-[#6B5A4C]" />
          </button>
        </div>

        {/* Trend Visualization */}
        <div className="bg-white rounded-2xl p-6 mb-4 shadow-sm border border-[#E5D5C5]">
          <div className="mb-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-[#6B5A4C]">Symptom Intensity</span>
              <div className="flex items-center gap-1">
                <div className="w-2 h-2 rounded-full bg-[#5D8A5E]"></div>
                <span className="text-xs text-[#6B5A4C]">Improving</span>
              </div>
            </div>
          </div>
          
          <svg width="100%" height={height} viewBox={`0 0 ${width} ${height}`} className="overflow-visible">
            {/* Gradient fill under curve */}
            <defs>
              <linearGradient id="trendGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#5D8A5E" stopOpacity="0.2" />
                <stop offset="100%" stopColor="#5D8A5E" stopOpacity="0" />
              </linearGradient>
            </defs>
            
            {/* Fill area */}
            <path
              d={`${pathD} L ${points[points.length - 1].x},${height - padding} L ${points[0].x},${height - padding} Z`}
              fill="url(#trendGradient)"
            />
            
            {/* Line */}
            <path
              d={pathD}
              fill="none"
              stroke="#5D8A5E"
              strokeWidth="3"
              strokeLinecap="round"
            />
            
            {/* Points */}
            {points.map((point, index) => (
              <g key={index}>
                <circle
                  cx={point.x}
                  cy={point.y}
                  r="5"
                  fill="white"
                  stroke="#5D8A5E"
                  strokeWidth="2"
                />
                <text
                  x={point.x}
                  y={height - 15}
                  textAnchor="middle"
                  className="text-xs fill-[#6B5A4C]"
                >
                  {trendData[index].label}
                </text>
              </g>
            ))}
          </svg>
        </div>

        {/* Insight Text */}
        <div className="bg-gradient-to-br from-[#D4EDD5] to-[#E5F4E6] rounded-2xl p-5 border border-[#B8D9B9]">
          <p className="text-[#2B2317] leading-relaxed">
            Your mornings have improved consistently over the past 6 days. You're experiencing 
            fewer symptoms and feeling calmer overall. Keep up the great work!
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 gap-3 mt-4">
          <div className="bg-white rounded-xl p-3 text-center border border-[#E5D5C5]">
            <div className="text-2xl mb-1">18%</div>
            <div className="text-xs text-[#6B5A4C]">Reduction</div>
          </div>
          <div className="bg-white rounded-xl p-3 text-center border border-[#E5D5C5]">
            <div className="text-2xl mb-1">6 days</div>
            <div className="text-xs text-[#6B5A4C]">Streak</div>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

function PatternModal({ onClose }: { onClose: () => void }) {
  const bubbleData: BubbleData[] = [
    { day: 'Mon', sleep: 6, symptom: 7 },
    { day: 'Tue', sleep: 7, symptom: 5 },
    { day: 'Wed', sleep: 8, symptom: 4 },
    { day: 'Thu', sleep: 7.5, symptom: 4 },
    { day: 'Fri', sleep: 8, symptom: 3 },
    { day: 'Sat', sleep: 9, symptom: 2 },
    { day: 'Sun', sleep: 8, symptom: 3 }
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-black/20 flex items-center justify-center p-6"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        onClick={(e) => e.stopPropagation()}
        className="bg-[#FBF7F4] rounded-3xl p-6 w-full max-w-md shadow-2xl max-h-[90vh] overflow-y-auto"
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#FFF3EB] to-[#FFE8D9] flex items-center justify-center">
              <Brain className="w-5 h-5 text-[#D9532E]" />
            </div>
            <div>
              <h3 className="text-[#2B2317]">Pattern Explorer</h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/50 rounded-full transition-colors"
          >
            <X className="w-5 h-5 text-[#6B5A4C]" />
          </button>
        </div>

        {/* Pattern Description */}
        <div className="bg-gradient-to-br from-[#FFF3EB] to-[#FFE8D9] rounded-2xl p-5 mb-6 border border-[#F5D5C0]">
          <div className="flex items-start gap-2 mb-2">
            <span className="text-2xl">💡</span>
            <p className="text-[#2B2317] leading-relaxed flex-1">
              You feel calmer on days after <span className="text-[#D9532E]">7+ hours of sleep</span>
            </p>
          </div>
          <div className="text-sm text-[#6B5A4C] mt-2">
            Based on 7 days of data • High confidence
          </div>
        </div>

        {/* Bubble Timeline */}
        <div className="bg-white rounded-2xl p-5 mb-4 shadow-sm border border-[#E5D5C5]">
          <div className="mb-4">
            <div className="flex items-center gap-4 text-xs text-[#6B5A4C] mb-4">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded-full bg-[#7BA8E8]"></div>
                <span>Sleep (hours)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded-full bg-[#E8734E]"></div>
                <span>Symptoms</span>
              </div>
            </div>
          </div>

          {/* Scrollable bubble view */}
          <div className="overflow-x-auto pb-4">
            <div className="flex gap-8 min-w-max px-2">
              {bubbleData.map((data, index) => (
                <div key={index} className="flex flex-col items-center gap-3">
                  <div className="text-xs text-[#6B5A4C] mb-1">{data.day}</div>
                  
                  {/* Sleep bubble */}
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: index * 0.1 }}
                    className="relative flex items-center justify-center rounded-full bg-gradient-to-br from-[#7BA8E8] to-[#5A8FD6] text-white shadow-lg"
                    style={{
                      width: `${data.sleep * 8}px`,
                      height: `${data.sleep * 8}px`
                    }}
                  >
                    <span className="text-xs font-medium">{data.sleep}</span>
                  </motion.div>

                  {/* Connecting line */}
                  <div className="w-0.5 h-4 bg-[#E5D5C5]"></div>

                  {/* Symptom bubble */}
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: index * 0.1 + 0.05 }}
                    className="relative flex items-center justify-center rounded-full bg-gradient-to-br from-[#E8734E] to-[#D9532E] text-white shadow-lg"
                    style={{
                      width: `${data.symptom * 8}px`,
                      height: `${data.symptom * 8}px`
                    }}
                  >
                    <span className="text-xs font-medium">{data.symptom}</span>
                  </motion.div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Insight */}
        <div className="bg-gradient-to-br from-[#D4EDD5] to-[#E5F4E6] rounded-2xl p-5 border border-[#B8D9B9]">
          <h4 className="text-[#2B2317] mb-2">What this means</h4>
          <p className="text-[#4A7A4B] text-sm leading-relaxed">
            When you get 7 or more hours of sleep, your symptoms consistently decrease the next day. 
            Prioritizing sleep could be your most powerful tool for feeling better.
          </p>
        </div>
      </motion.div>
    </motion.div>
  );
}

function MomentumModal({ onClose }: { onClose: () => void }) {
  const progress = 57; // out of 100

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-black/20 flex items-center justify-center p-6"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        onClick={(e) => e.stopPropagation()}
        className="bg-[#FBF7F4] rounded-3xl p-6 w-full max-w-md shadow-2xl"
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#FFF9E6] to-[#FFF3CC] flex items-center justify-center">
              <Flame className="w-5 h-5 text-[#E8A33E]" />
            </div>
            <div>
              <h3 className="text-[#2B2317]">Your Progress Story</h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/50 rounded-full transition-colors"
          >
            <X className="w-5 h-5 text-[#6B5A4C]" />
          </button>
        </div>

        {/* Celebration */}
        <div className="bg-gradient-to-br from-[#FFF9E6] to-[#FFF3CC] rounded-2xl p-6 mb-6 border border-[#F5E5B8] text-center">
          <motion.div
            initial={{ scale: 0, rotate: -180 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ type: 'spring', duration: 0.6 }}
            className="text-5xl mb-3"
          >
            🔥
          </motion.div>
          <div className="text-3xl mb-2">4-day streak!</div>
          <p className="text-[#8B7355]">
            You're on fire this week
          </p>
        </div>

        {/* Progress Bar */}
        <div className="bg-white rounded-2xl p-5 mb-4 shadow-sm border border-[#E5D5C5]">
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm text-[#6B5A4C]">Weekly Progress</span>
            <span className="text-sm text-[#D9532E]">{progress}%</span>
          </div>
          <div className="w-full h-3 bg-[#F5E5D5] rounded-full overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 1, ease: 'easeOut' }}
              className="h-full bg-gradient-to-r from-[#E8A33E] to-[#D9532E] rounded-full"
            />
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-3 gap-3 mb-4">
          <div className="bg-white rounded-xl p-4 text-center border border-[#E5D5C5]">
            <div className="text-2xl mb-1">12</div>
            <div className="text-xs text-[#6B5A4C]">Logs this week</div>
          </div>
          <div className="bg-white rounded-xl p-4 text-center border border-[#E5D5C5]">
            <div className="text-2xl mb-1">4</div>
            <div className="text-xs text-[#6B5A4C]">Days tracked</div>
          </div>
          <div className="bg-white rounded-xl p-4 text-center border border-[#E5D5C5]">
            <div className="text-2xl mb-1">3</div>
            <div className="text-xs text-[#6B5A4C]">New insights</div>
          </div>
        </div>

        {/* Insight */}
        <div className="bg-gradient-to-br from-[#D4EDD5] to-[#E5F4E6] rounded-2xl p-5 border border-[#B8D9B9]">
          <p className="text-[#4A7A4B] text-sm leading-relaxed">
            <span className="text-[#2B2317]">Consistency unlocks insights.</span> The more you log, 
            the better we understand your patterns and the more accurate your personalized insights become.
          </p>
        </div>

        {/* Confetti particles */}
        {[...Array(8)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, scale: 0, x: 0, y: 0 }}
            animate={{
              opacity: [0, 1, 0],
              scale: [0, 1, 0.5],
              x: Math.cos((i * Math.PI * 2) / 8) * 100,
              y: Math.sin((i * Math.PI * 2) / 8) * 100,
            }}
            transition={{ delay: 0.2, duration: 1 }}
            className="absolute top-1/4 left-1/2 w-2 h-2 rounded-full pointer-events-none"
            style={{
              backgroundColor: ['#E8A33E', '#D9532E', '#5D8A5E', '#7BA8E8'][i % 4],
            }}
          />
        ))}
      </motion.div>
    </motion.div>
  );
}

export function ReflectSection({ onNavigateToCircle }: { onNavigateToCircle?: () => void }) {
  const [activeModal, setActiveModal] = useState<'insight' | 'pattern' | 'momentum' | null>(null);

  return (
    <>
      <section className="px-6 py-4">
        <h3 className="text-[#3D2F24] mb-4 px-1">Reflect</h3>
        
        {/* Card 1 - Insight of the Day */}
        <button
          onClick={() => setActiveModal('insight')}
          className="w-full bg-gradient-to-br from-[#D4EDD5] to-[#E5F4E6] rounded-3xl p-5 shadow-sm border border-[#B8D9B9] mb-3 text-left hover:shadow-md transition-all hover:scale-[1.01]"
        >
          <div className="flex items-start justify-between gap-3 mb-3">
            <div className="flex items-start gap-3 flex-1">
              <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-sm flex-shrink-0">
                <Sparkles className="w-6 h-6 text-[#5D8A5E]" />
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="text-sm text-[#4A7A4B] mb-1">Insight of the Day</h4>
                <p className="text-[#2B2317]">
                  Symptoms down 18% compared to last week ✨
                </p>
              </div>
            </div>
            <div className="flex items-center justify-center w-8 h-8 bg-[#5D8A5E] rounded-full flex-shrink-0">
              <TrendingDown className="w-4 h-4 text-white" />
            </div>
          </div>
          <div className="text-sm text-[#4A7A4B] pl-[60px]">
            Nice progress!
          </div>
        </button>

        {/* Card 2 - Your Strongest Pattern This Week */}
        <button
          onClick={() => setActiveModal('pattern')}
          className="w-full bg-gradient-to-br from-[#FFF3EB] to-[#FFE8D9] rounded-3xl p-5 shadow-sm border border-[#F5D5C0] mb-3 text-left hover:shadow-md transition-all hover:scale-[1.01]"
        >
          <div className="flex items-start justify-between gap-3 mb-3">
            <div className="flex items-start gap-3 flex-1">
              <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-sm flex-shrink-0">
                <Brain className="w-6 h-6 text-[#D9532E]" />
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="text-sm text-[#8B6F5F] mb-1">Your Strongest Pattern This Week</h4>
                <p className="text-[#2B2317]">
                  You feel calmer on days after 7+ hours of sleep 💡
                </p>
              </div>
            </div>
          </div>
          <div className="text-sm text-[#8B6F5F] pl-[60px]">
            High confidence • Based on your data
          </div>
        </button>

        {/* Card 3 - Your Circle */}
        <button
          onClick={onNavigateToCircle}
          className="w-full bg-gradient-to-br from-[#E8F3F8] to-[#D4E9F2] rounded-3xl p-5 shadow-sm border border-[#C1DEE9] mb-3 text-left hover:shadow-md transition-all hover:scale-[1.01]"
        >
          <div className="flex items-start justify-between gap-3 mb-3">
            <div className="flex items-start gap-3 flex-1">
              <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-sm flex-shrink-0">
                <Users className="w-6 h-6 text-[#5A8FD6]" />
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="text-sm text-[#4A6B8A] mb-1">Your Circle</h4>
                <p className="text-[#2B2317]">
                  People like you also report calmer mornings after consistent sleep 🤝
                </p>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-[#5A8FD6] flex-shrink-0 mt-3" />
          </div>
          <div className="text-sm text-[#4A6B8A] pl-[60px]">
            See more in Community
          </div>
        </button>

        {/* Card 4 - Your Momentum */}
        <button
          onClick={() => setActiveModal('momentum')}
          className="w-full bg-gradient-to-br from-[#FFF9E6] to-[#FFF3CC] rounded-3xl p-5 shadow-sm border border-[#F5E5B8] text-left hover:shadow-md transition-all hover:scale-[1.01]"
        >
          <div className="flex items-start justify-between gap-3 mb-3">
            <div className="flex items-start gap-3 flex-1">
              <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-sm flex-shrink-0">
                <Flame className="w-6 h-6 text-[#E8A33E]" />
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="text-sm text-[#8B7355] mb-1">Your Momentum</h4>
                <p className="text-[#2B2317]">
                  4-day streak! 🔥
                </p>
              </div>
            </div>
          </div>
          <div className="text-sm text-[#8B7355] pl-[60px]">
            Your logging is improving insight accuracy
          </div>
        </button>
      </section>

      {/* Modals */}
      <AnimatePresence>
        {activeModal === 'insight' && (
          <InsightModal onClose={() => setActiveModal(null)} />
        )}
        {activeModal === 'pattern' && (
          <PatternModal onClose={() => setActiveModal(null)} />
        )}
        {activeModal === 'momentum' && (
          <MomentumModal onClose={() => setActiveModal(null)} />
        )}
      </AnimatePresence>
    </>
  );
}
