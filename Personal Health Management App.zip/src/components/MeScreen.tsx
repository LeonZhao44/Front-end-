import { TopBar } from './TopBar';
import { LogSection } from './LogSection';
import { ReflectSection } from './ReflectSection';
import { UnderstandSection } from './UnderstandSection';

export function MeScreen({ onNavigateToCommunity }: { onNavigateToCommunity?: () => void }) {
  return (
    <div>
      <TopBar />
      <LogSection />
      <ReflectSection onNavigateToCircle={onNavigateToCommunity} />
      <UnderstandSection />
    </div>
  );
}