import { useState } from 'react';
import { 
  Users, 
  Globe, 
  Lightbulb, 
  TrendingUp, 
  Heart, 
  MessageCircle, 
  Sprout,
  X,
  Camera,
  ChevronRight,
  ChevronLeft
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { TopBar } from './TopBar';

type Tab = 'circle' | 'everyone';
type MomentCategory = 'breakfast' | 'calm' | 'sleep' | 'movement' | 'doctor' | 'food';

interface Moment {
  id: string;
  imageUrl: string;
  category: MomentCategory;
  categoryLabel: string;
  categoryEmoji: string;
  reactions: {
    growth: number;
    understanding: number;
    support: number;
  };
  username: string;
}

const circleMoments: Moment[] = [
  {
    id: '1',
    imageUrl: 'https://images.unsplash.com/photo-1645517976245-569a91016f79?crop=entropy&cs=tinysrgb&fit=max&fm=jpg',
    category: 'breakfast',
    categoryLabel: 'Breakfast log',
    categoryEmoji: '🥣',
    reactions: { growth: 12, understanding: 8, support: 15 },
    username: 'Sarah'
  },
  {
    id: '2',
    imageUrl: 'https://images.unsplash.com/photo-1705304367364-05fa6db71329?crop=entropy&cs=tinysrgb&fit=max&fm=jpg',
    category: 'sleep',
    categoryLabel: 'Sleep setup',
    categoryEmoji: '🌙',
    reactions: { growth: 18, understanding: 5, support: 22 },
    username: 'Emma'
  },
  {
    id: '3',
    imageUrl: 'https://images.unsplash.com/photo-1736822240838-045f1fd94b63?crop=entropy&cs=tinysrgb&fit=max&fm=jpg',
    category: 'movement',
    categoryLabel: 'Movement',
    categoryEmoji: '🚶‍♀️',
    reactions: { growth: 25, understanding: 12, support: 19 },
    username: 'Alex'
  },
  {
    id: '4',
    imageUrl: 'https://images.unsplash.com/photo-1734830251466-305b75c8da39?crop=entropy&cs=tinysrgb&fit=max&fm=jpg',
    category: 'calm',
    categoryLabel: 'Calm moment',
    categoryEmoji: '🌿',
    reactions: { growth: 30, understanding: 14, support: 28 },
    username: 'Jordan'
  }
];

const everyoneMoments: Moment[] = [
  {
    id: '5',
    imageUrl: 'https://images.unsplash.com/photo-1641971215228-c677f3a28cd8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg',
    category: 'movement',
    categoryLabel: 'Movement',
    categoryEmoji: '🚶‍♀️',
    reactions: { growth: 45, understanding: 32, support: 58 },
    username: 'Maria'
  },
  {
    id: '6',
    imageUrl: 'https://images.unsplash.com/photo-1543352632-5a4b24e4d2a6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg',
    category: 'food',
    categoryLabel: 'Food log',
    categoryEmoji: '🥗',
    reactions: { growth: 38, understanding: 25, support: 41 },
    username: 'Chris'
  },
  ...circleMoments.slice(0, 2)
];

function ShareMomentModal({ onClose }: { onClose: () => void }) {
  const [selectedCategory, setSelectedCategory] = useState<MomentCategory | null>(null);
  
  const categories = [
    { id: 'breakfast' as MomentCategory, label: 'Breakfast log', emoji: '🥣', color: '#FFF3EB' },
    { id: 'food' as MomentCategory, label: 'Food log', emoji: '🥗', color: '#E5F4E6' },
    { id: 'calm' as MomentCategory, label: 'Calm moment', emoji: '🌿', color: '#D4EDD5' },
    { id: 'sleep' as MomentCategory, label: 'Sleep setup', emoji: '🌙', color: '#E8F3F8' },
    { id: 'movement' as MomentCategory, label: 'Movement', emoji: '🚶‍♀️', color: '#F5E8FF' },
    { id: 'doctor' as MomentCategory, label: 'Doctor day', emoji: '🏥', color: '#FFE8E8' }
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-black/40 flex items-end"
      onClick={onClose}
    >
      <motion.div
        initial={{ y: '100%' }}
        animate={{ y: 0 }}
        exit={{ y: '100%' }}
        transition={{ type: 'spring', damping: 30, stiffness: 300 }}
        onClick={(e) => e.stopPropagation()}
        className="w-full bg-[#FBF7F4] rounded-t-[32px] shadow-2xl max-w-md mx-auto pb-8"
      >
        {/* Drag handle */}
        <div className="flex justify-center pt-3 pb-2">
          <div className="w-12 h-1.5 bg-[#D5C5B5] rounded-full"></div>
        </div>

        <div className="px-6 pt-2">
          <h2 className="text-[#2B2317] mb-6 text-center">Share a Moment</h2>

          {/* Photo Selector */}
          <button className="w-full aspect-square bg-gradient-to-br from-[#FFF3EB] to-[#FFE8D9] rounded-3xl border-2 border-dashed border-[#E5D5C5] flex flex-col items-center justify-center gap-3 mb-6 hover:border-[#D9532E] transition-colors">
            <Camera className="w-12 h-12 text-[#D9532E]" />
            <span className="text-[#6B5A4C]">Tap to add photo</span>
          </button>

          {/* Category Selection */}
          <div className="mb-6">
            <h3 className="text-sm text-[#6B5A4C] mb-3">What kind of moment is this?</h3>
            <div className="grid grid-cols-2 gap-2">
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`p-4 rounded-2xl border transition-all text-left ${
                    selectedCategory === cat.id
                      ? 'border-[#D9532E] shadow-md'
                      : 'border-[#E5D5C5]'
                  }`}
                  style={{ backgroundColor: cat.color }}
                >
                  <div className="text-2xl mb-1">{cat.emoji}</div>
                  <div className="text-sm text-[#2B2317]">{cat.label}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Share Button */}
          <button
            disabled={!selectedCategory}
            className="w-full py-4 rounded-2xl bg-gradient-to-br from-[#E8734E] to-[#D9532E] text-white shadow-lg hover:shadow-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Share with Circle
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

function CircleOverviewModal({ onClose }: { onClose: () => void }) {
  const moodData = [
    { label: 'Calm', percent: 45, color: '#5D8A5E' },
    { label: 'Hopeful', percent: 30, color: '#7BA8E8' },
    { label: 'Stressed', percent: 15, color: '#E8734E' },
    { label: 'Neutral', percent: 10, color: '#E8A33E' }
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-[#FBF7F4] overflow-y-auto"
    >
      <div className="px-6 py-6">
        <button onClick={onClose} className="p-2 -ml-2 hover:bg-white/50 rounded-full transition-colors mb-4">
          <ChevronLeft className="w-5 h-5 text-[#6B5A4C]" />
        </button>

        <h2 className="text-[#2B2317] mb-2">Circle Dashboard</h2>
        <p className="text-[#6B5A4C] mb-2">How your Circle is feeling today</p>
        <p className="text-xs text-[#9B8B7D] mb-6">
          Your Circle is made up of people with similar patterns and health experiences based on your onboarding responses
        </p>

        {/* Donut Chart Visualization */}
        <div className="bg-gradient-to-br from-[#E8F3F8] to-[#D4EDD5] rounded-3xl p-8 mb-6 border border-[#B8D9B9]">
          <div className="flex flex-col items-center">
            <div className="relative w-48 h-48 mb-6">
              <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                {/* Background circle */}
                <circle
                  cx="50"
                  cy="50"
                  r="40"
                  fill="none"
                  stroke="#F5E5D5"
                  strokeWidth="20"
                />
                {/* Mood segments */}
                {(() => {
                  let currentAngle = 0;
                  return moodData.map((mood, i) => {
                    const angle = (mood.percent / 100) * 360;
                    const dashArray = (angle / 360) * (2 * Math.PI * 40);
                    const dashOffset = -(currentAngle / 360) * (2 * Math.PI * 40);
                    currentAngle += angle;
                    
                    return (
                      <circle
                        key={i}
                        cx="50"
                        cy="50"
                        r="40"
                        fill="none"
                        stroke={mood.color}
                        strokeWidth="20"
                        strokeDasharray={`${dashArray} ${2 * Math.PI * 40}`}
                        strokeDashoffset={dashOffset}
                        className="transition-all duration-500"
                      />
                    );
                  });
                })()}
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <div className="text-3xl mb-1">👥</div>
                <div className="text-sm text-[#6B5A4C]">Your Circle</div>
              </div>
            </div>

            {/* Legend */}
            <div className="space-y-2 w-full">
              {moodData.map((mood, i) => (
                <div key={i} className="flex items-center justify-between bg-white/50 rounded-xl px-4 py-2">
                  <div className="flex items-center gap-3">
                    <div 
                      className="w-3 h-3 rounded-full" 
                      style={{ backgroundColor: mood.color }}
                    />
                    <span className="text-sm text-[#2B2317]">{mood.label}</span>
                  </div>
                  <span className="text-sm text-[#6B5A4C]">{mood.percent}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Insight */}
        <div className="bg-gradient-to-br from-[#D4EDD5] to-[#E5F4E6] rounded-2xl p-5 border border-[#B8D9B9]">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-full bg-[#5D8A5E] flex items-center justify-center flex-shrink-0">
              <TrendingUp className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-[#2B2317] mb-1">Trending calmer</h3>
              <p className="text-sm text-[#4A7A4B]">
                Your Circle is trending calmer than last week, with more people reporting peaceful mornings.
              </p>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function SharedPatternModal({ onClose }: { onClose: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-[#FBF7F4] overflow-y-auto"
    >
      <div className="px-6 py-6">
        <button onClick={onClose} className="p-2 -ml-2 hover:bg-white/50 rounded-full transition-colors mb-4">
          <ChevronLeft className="w-5 h-5 text-[#6B5A4C]" />
        </button>

        <h2 className="text-[#2B2317] mb-2">Shared Pattern</h2>
        <p className="text-[#6B5A4C] mb-6">What your Circle is discovering</p>

        {/* Pattern visualization */}
        <div className="bg-white rounded-3xl p-6 mb-6 border border-[#E5D5C5]">
          <h3 className="text-[#2B2317] mb-4">Sleep consistency → Calmer afternoons</h3>
          
          {/* Organic curved chart */}
          <div className="relative h-48 mb-4">
            <svg className="w-full h-full" viewBox="0 0 300 150" preserveAspectRatio="none">
              {/* Grid lines */}
              <line x1="0" y1="37.5" x2="300" y2="37.5" stroke="#F5E5D5" strokeWidth="1" />
              <line x1="0" y1="75" x2="300" y2="75" stroke="#F5E5D5" strokeWidth="1" />
              <line x1="0" y1="112.5" x2="300" y2="112.5" stroke="#F5E5D5" strokeWidth="1" />
              
              {/* Your line (more jagged) */}
              <path
                d="M 0 100 Q 50 110, 75 105 T 150 90 Q 200 85, 225 80 T 300 70"
                fill="none"
                stroke="#7BA8E8"
                strokeWidth="3"
                strokeLinecap="round"
              />
              
              {/* Circle line (smoother, better) */}
              <path
                d="M 0 110 Q 50 100, 75 95 T 150 70 Q 200 60, 225 55 T 300 45"
                fill="none"
                stroke="#5D8A5E"
                strokeWidth="3"
                strokeLinecap="round"
              />
              
              {/* Data points */}
              <circle cx="75" cy="105" r="4" fill="#7BA8E8" />
              <circle cx="150" cy="90" r="4" fill="#7BA8E8" />
              <circle cx="225" cy="80" r="4" fill="#7BA8E8" />
              
              <circle cx="75" cy="95" r="4" fill="#5D8A5E" />
              <circle cx="150" cy="70" r="4" fill="#5D8A5E" />
              <circle cx="225" cy="55" r="4" fill="#5D8A5E" />
            </svg>
            
            {/* Labels */}
            <div className="absolute bottom-0 left-0 right-0 flex justify-between text-xs text-[#9B8B7D]">
              <span>Mon</span>
              <span>Wed</span>
              <span>Fri</span>
              <span>Sun</span>
            </div>
          </div>

          {/* Legend */}
          <div className="flex gap-4 justify-center">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-[#7BA8E8]" />
              <span className="text-sm text-[#6B5A4C]">You</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-[#5D8A5E]" />
              <span className="text-sm text-[#6B5A4C]">Your Circle</span>
            </div>
          </div>
        </div>

        {/* Bubble correlation */}
        <div className="bg-gradient-to-br from-[#FFF3EB] to-[#FFE8D9] rounded-3xl p-6 mb-6 border border-[#F5D5C0]">
          <h3 className="text-[#2B2317] mb-4">The connection</h3>
          
          <div className="relative h-40 flex items-center justify-center gap-8">
            {/* Sleep bubble */}
            <div className="text-center">
              <div className="w-24 h-24 rounded-full bg-[#E8F3F8] border-2 border-[#7BA8E8] flex items-center justify-center mb-2">
                <span className="text-3xl">🌙</span>
              </div>
              <div className="text-sm text-[#6B5A4C]">Consistent<br/>sleep</div>
            </div>

            {/* Arrow */}
            <ChevronRight className="w-6 h-6 text-[#D9532E]" />

            {/* Calm bubble */}
            <div className="text-center">
              <div className="w-24 h-24 rounded-full bg-[#D4EDD5] border-2 border-[#5D8A5E] flex items-center justify-center mb-2">
                <span className="text-3xl">😌</span>
              </div>
              <div className="text-sm text-[#6B5A4C]">Calmer<br/>afternoons</div>
            </div>
          </div>
        </div>

        {/* Explanation */}
        <div className="bg-white rounded-2xl p-5 border border-[#E5D5C5]">
          <p className="text-[#2B2317] leading-relaxed">
            People in your Circle who maintain consistent sleep schedules (going to bed and waking at similar times) 
            report 40% calmer afternoons. The effect is strongest when sleep consistency is maintained for 3+ days.
          </p>
        </div>
      </div>
    </motion.div>
  );
}

function CircleExperimentsModal({ onClose }: { onClose: () => void }) {
  const experiments = [
    {
      id: '1',
      name: 'Earlier dinner',
      emoji: '🥗',
      percent: 68,
      trying: 12,
      why: 'Eating 3-4 hours before bed to improve sleep and reduce nighttime symptoms',
      feeling: 'Most report less bloating and better sleep quality',
      color: '#E5F4E6'
    },
    {
      id: '2',
      name: 'Less coffee before 10am',
      emoji: '☕',
      percent: 45,
      trying: 8,
      why: 'Reducing morning cortisol spikes that can trigger digestive symptoms',
      feeling: 'Mixed results - some feel calmer, others miss the energy boost',
      color: '#FFF3EB'
    },
    {
      id: '3',
      name: 'Evening walk',
      emoji: '🚶‍♂️',
      percent: 82,
      trying: 15,
      why: 'Light movement after dinner to aid digestion and reduce stress',
      feeling: 'High satisfaction - people report better mood and easier digestion',
      color: '#E8F3F8'
    }
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-[#FBF7F4] overflow-y-auto"
    >
      <div className="px-6 py-6 pb-20">
        <button onClick={onClose} className="p-2 -ml-2 hover:bg-white/50 rounded-full transition-colors mb-4">
          <ChevronLeft className="w-5 h-5 text-[#6B5A4C]" />
        </button>

        <h2 className="text-[#2B2317] mb-2">Circle Experiments</h2>
        <p className="text-[#6B5A4C] mb-6">What your Circle is trying</p>

        <div className="space-y-4">
          {experiments.map((exp) => (
            <div key={exp.id} className="bg-white rounded-3xl p-6 border border-[#E5D5C5]">
              <div className="flex items-start gap-4 mb-4">
                <div 
                  className="w-14 h-14 rounded-2xl flex items-center justify-center text-2xl flex-shrink-0"
                  style={{ backgroundColor: exp.color }}
                >
                  {exp.emoji}
                </div>
                <div className="flex-1">
                  <h3 className="text-[#2B2317] mb-1">{exp.name}</h3>
                  <div className="flex items-center gap-2 text-sm text-[#6B5A4C]">
                    <span>{exp.trying} people trying</span>
                    <span>•</span>
                    <span>{exp.percent}% positive</span>
                  </div>
                </div>
              </div>

              {/* Progress bar */}
              <div className="mb-4">
                <div className="h-2 bg-[#F5E5D5] rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-[#5D8A5E] to-[#7BA8E8] rounded-full transition-all"
                    style={{ width: `${exp.percent}%` }}
                  />
                </div>
              </div>

              {/* Details */}
              <div className="space-y-3">
                <div className="bg-[#FBF7F4] rounded-2xl p-4">
                  <div className="text-xs text-[#9B8B7D] mb-1">Why they're trying it</div>
                  <p className="text-sm text-[#2B2317]">{exp.why}</p>
                </div>
                <div className="bg-[#FBF7F4] rounded-2xl p-4">
                  <div className="text-xs text-[#9B8B7D] mb-1">How they feel</div>
                  <p className="text-sm text-[#2B2317]">{exp.feeling}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}

function WeekComparisonModal({ onClose }: { onClose: () => void }) {
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const yourMoods = ['😌', '🙂', '😌', '😐', '🙂', '😌', '😊'];
  const circleMoods = ['😐', '😐', '🙂', '😕', '😐', '🙂', '😌'];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-[#FBF7F4] overflow-y-auto"
    >
      <div className="px-6 py-6">
        <button onClick={onClose} className="p-2 -ml-2 hover:bg-white/50 rounded-full transition-colors mb-4">
          <ChevronLeft className="w-5 h-5 text-[#6B5A4C]" />
        </button>

        <h2 className="text-[#2B2317] mb-2">Your Week vs Circle</h2>
        <p className="text-[#6B5A4C] mb-6">How you compared to your Circle this week</p>

        {/* Week grid */}
        <div className="bg-white rounded-3xl p-6 mb-6 border border-[#E5D5C5]">
          <div className="space-y-6">
            {/* Your week */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <div className="text-sm text-[#6B5A4C]">You</div>
              </div>
              <div className="grid grid-cols-7 gap-2">
                {days.map((day, i) => (
                  <div key={i} className="text-center">
                    <div className="text-xs text-[#9B8B7D] mb-2">{day}</div>
                    <div className="aspect-square bg-gradient-to-br from-[#D4EDD5] to-[#E5F4E6] rounded-2xl flex items-center justify-center text-2xl border border-[#B8D9B9]">
                      {yourMoods[i]}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Circle week */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <div className="text-sm text-[#6B5A4C]">Circle Average</div>
              </div>
              <div className="grid grid-cols-7 gap-2">
                {days.map((day, i) => (
                  <div key={i} className="text-center">
                    <div className="text-xs text-[#9B8B7D] mb-2">{day}</div>
                    <div className="aspect-square bg-gradient-to-br from-[#F5E5D5] to-[#EBDAC5] rounded-2xl flex items-center justify-center text-2xl border border-[#E5D5C5]">
                      {circleMoods[i]}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Achievement */}
        <div className="bg-gradient-to-br from-[#D4EDD5] to-[#E5F4E6] rounded-3xl p-6 border border-[#B8D9B9]">
          <div className="flex items-center gap-4 mb-3">
            <div className="w-12 h-12 rounded-full bg-[#5D8A5E] flex items-center justify-center flex-shrink-0">
              <span className="text-2xl">🌱</span>
            </div>
            <div>
              <h3 className="text-[#2B2317] mb-1">Great week!</h3>
              <p className="text-sm text-[#4A7A4B]">
                Your mornings were calmer than your Circle's average. Whatever you're doing is working!
              </p>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function LoggingConsistencyModal({ onClose }: { onClose: () => void }) {
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const yourLogs = [true, true, false, true, true, true, true]; // 6 out of 7
  const circleLogs = [true, false, true, false, true, false, true]; // 4 out of 7 average

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-[#FBF7F4] overflow-y-auto"
    >
      <div className="px-6 py-6">
        <button onClick={onClose} className="p-2 -ml-2 hover:bg-white/50 rounded-full transition-colors mb-4">
          <ChevronLeft className="w-5 h-5 text-[#6B5A4C]" />
        </button>

        <h2 className="text-[#2B2317] mb-2">Logging Consistency</h2>
        <p className="text-[#6B5A4C] mb-6">Your tracking habits compared to your Circle</p>

        {/* Consistency comparison */}
        <div className="bg-white rounded-3xl p-6 mb-6 border border-[#E5D5C5]">
          <div className="space-y-6">
            {/* Your logs */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="text-sm text-[#6B5A4C]">You logged</div>
                <div className="text-sm text-[#5D8A5E]">6 out of 7 days</div>
              </div>
              <div className="grid grid-cols-7 gap-2">
                {days.map((day, i) => (
                  <div key={i} className="text-center">
                    <div className="text-xs text-[#9B8B7D] mb-2">{day}</div>
                    <div className={`aspect-square rounded-2xl flex items-center justify-center ${
                      yourLogs[i]
                        ? 'bg-gradient-to-br from-[#D4EDD5] to-[#E5F4E6] border border-[#B8D9B9]'
                        : 'bg-[#F5E5D5] border border-[#E5D5C5]'
                    }`}>
                      <span className="text-lg">{yourLogs[i] ? '✓' : '—'}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Circle average */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="text-sm text-[#6B5A4C]">Circle Average</div>
                <div className="text-sm text-[#9B8B7D]">4 out of 7 days</div>
              </div>
              <div className="grid grid-cols-7 gap-2">
                {days.map((day, i) => (
                  <div key={i} className="text-center">
                    <div className="text-xs text-[#9B8B7D] mb-2">{day}</div>
                    <div className={`aspect-square rounded-2xl flex items-center justify-center ${
                      circleLogs[i]
                        ? 'bg-gradient-to-br from-[#F5E5D5] to-[#EBDAC5] border border-[#E5D5C5]'
                        : 'bg-[#F5E5D5] border border-[#E5D5C5]'
                    }`}>
                      <span className="text-lg">{circleLogs[i] ? '✓' : '—'}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Stats card */}
        <div className="bg-gradient-to-br from-[#D4EDD5] to-[#E5F4E6] rounded-3xl p-6 mb-4 border border-[#B8D9B9]">
          <div className="flex items-center gap-4 mb-3">
            <div className="w-12 h-12 rounded-full bg-[#5D8A5E] flex items-center justify-center flex-shrink-0">
              <span className="text-2xl">📊</span>
            </div>
            <div>
              <h3 className="text-[#2B2317] mb-1">Strong tracking habit</h3>
              <p className="text-sm text-[#4A7A4B]">
                You logged 6 days this week. Consistent tracking helps reveal patterns.
              </p>
            </div>
          </div>
        </div>

        {/* Info card */}
        <div className="bg-white rounded-2xl p-5 border border-[#E5D5C5]">
          <p className="text-sm text-[#6B5A4C] leading-relaxed">
            Research shows that people who log at least 5 days per week are 3× more likely to discover 
            meaningful patterns in their health data.
          </p>
        </div>
      </div>
    </motion.div>
  );
}

function MomentCard({ moment, onReact }: { moment: Moment; onReact: (type: 'growth' | 'understanding' | 'support') => void }) {
  return (
    <div className="flex-shrink-0 w-64">
      <div className="relative rounded-3xl overflow-hidden shadow-md">
        <ImageWithFallback
          src={moment.imageUrl}
          alt={moment.categoryLabel}
          className="w-full aspect-square object-cover"
        />
        
        {/* Category tag */}
        <div className="absolute top-3 left-3 px-3 py-1.5 bg-white/90 backdrop-blur-sm rounded-full flex items-center gap-2 shadow-sm">
          <span className="text-sm">{moment.categoryEmoji}</span>
          <span className="text-xs text-[#2B2317]">{moment.categoryLabel}</span>
        </div>

        {/* Username */}
        <div className="absolute top-3 right-3 px-3 py-1.5 bg-black/30 backdrop-blur-sm rounded-full">
          <span className="text-xs text-white">{moment.username}</span>
        </div>

        {/* Reactions */}
        <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/60 to-transparent">
          <div className="flex gap-2">
            <button
              onClick={() => onReact('growth')}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-white/90 backdrop-blur-sm rounded-full hover:bg-white transition-colors"
            >
              <span className="text-sm">🌱</span>
              <span className="text-xs text-[#2B2317]">{moment.reactions.growth}</span>
            </button>
            <button
              onClick={() => onReact('understanding')}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-white/90 backdrop-blur-sm rounded-full hover:bg-white transition-colors"
            >
              <span className="text-sm">💬</span>
              <span className="text-xs text-[#2B2317]">{moment.reactions.understanding}</span>
            </button>
            <button
              onClick={() => onReact('support')}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-white/90 backdrop-blur-sm rounded-full hover:bg-white transition-colors"
            >
              <span className="text-sm">❤️‍🩹</span>
              <span className="text-xs text-[#2B2317]">{moment.reactions.support}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export function CommunityScreen() {
  const [activeTab, setActiveTab] = useState<Tab>('circle');
  const [showShareModal, setShowShareModal] = useState(false);
  const [selectedModal, setSelectedModal] = useState<string | null>(null);

  const handleReact = (momentId: string, type: string) => {
    console.log('Reacted to moment', momentId, 'with', type);
  };

  return (
    <>
      <div className="min-h-screen bg-[#FBF7F4]">
        <TopBar />

        {/* Tab Navigation */}
        <div className="px-6 py-4">
          <div className="bg-white rounded-full p-1 shadow-sm border border-[#E5D5C5] inline-flex">
            <button
              onClick={() => setActiveTab('circle')}
              className={`px-6 py-2 rounded-full transition-all ${
                activeTab === 'circle'
                  ? 'bg-gradient-to-r from-[#E8734E] to-[#D9532E] text-white shadow-md'
                  : 'text-[#6B5A4C]'
              }`}
            >
              My Circle
            </button>
            <button
              onClick={() => setActiveTab('everyone')}
              className={`px-6 py-2 rounded-full transition-all ${
                activeTab === 'everyone'
                  ? 'bg-gradient-to-r from-[#E8734E] to-[#D9532E] text-white shadow-md'
                  : 'text-[#6B5A4C]'
              }`}
            >
              Everyone
            </button>
          </div>
        </div>

        {/* My Circle Tab */}
        {activeTab === 'circle' && (
          <div className="px-6 pb-20 space-y-4">
            {/* Circle Overview Card */}
            <button
              onClick={() => setSelectedModal('circleOverview')}
              className="w-full bg-gradient-to-br from-[#E8F3F8] to-[#D4EDD5] rounded-3xl p-6 shadow-sm border border-[#B8D9B9] text-left hover:shadow-md transition-all"
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="text-[#2B2317] mb-2">Your Circle Today</h3>
                  <p className="text-sm text-[#4A7A4B]">
                    People like you are having a calmer week
                  </p>
                </div>
                <div className="flex gap-1">
                  <span className="text-xl">👥</span>
                  <span className="text-xl">💬</span>
                  <span className="text-xl">✨</span>
                </div>
              </div>
              <div className="flex items-center gap-2 text-[#5D8A5E]">
                <TrendingUp className="w-4 h-4" />
                <span className="text-sm">View details →</span>
              </div>
            </button>

            {/* Shared Pattern Card */}
            <button
              onClick={() => setSelectedModal('sharedPattern')}
              className="w-full bg-gradient-to-br from-[#FFF3EB] to-[#FFE8D9] rounded-3xl p-6 shadow-sm border border-[#F5D5C0] text-left hover:shadow-md transition-all"
            >
              <div className="flex items-start gap-4 mb-3">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#E8734E] to-[#D9532E] flex items-center justify-center flex-shrink-0">
                  <Lightbulb className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="text-[#2B2317] mb-2">Shared Pattern</h3>
                  <p className="text-sm text-[#8B6F5F]">
                    Your Circle reports calmer afternoons when sleep is consistent
                  </p>
                </div>
                <div className="text-2xl">✓</div>
              </div>
              <div className="text-sm text-[#D9532E]">
                Explore in detail →
              </div>
            </button>

            {/* Circle Experiments Card */}
            <button
              onClick={() => setSelectedModal('circleExperiments')}
              className="w-full bg-white rounded-3xl p-6 shadow-sm border border-[#E5D5C5] text-left hover:shadow-md transition-all"
            >
              <h3 className="text-[#2B2317] mb-4">What your Circle is trying</h3>
              <div className="flex flex-wrap gap-2 mb-3">
                <div className="px-4 py-2 bg-[#E5F4E6] rounded-full text-sm text-[#5D8A5E] border border-[#B8D9B9]">
                  🥗 Earlier dinner <span className="text-xs text-[#9B8B7D]">68%</span>
                </div>
                <div className="px-4 py-2 bg-[#FFF3EB] rounded-full text-sm text-[#E8734E] border border-[#F5D5C0]">
                  ☕ Less coffee <span className="text-xs text-[#9B8B7D]">45%</span>
                </div>
                <div className="px-4 py-2 bg-[#E8F3F8] rounded-full text-sm text-[#5A8FD6] border border-[#C1DEE9]">
                  🚶‍♂️ Evening walk <span className="text-xs text-[#9B8B7D]">82%</span>
                </div>
              </div>
              <div className="text-sm text-[#D9532E]">
                See all experiments →
              </div>
            </button>

            {/* My Week vs Circle Card */}
            <button
              onClick={() => setSelectedModal('weekComparison')}
              className="w-full bg-gradient-to-br from-[#D4EDD5] to-[#E5F4E6] rounded-3xl p-6 shadow-sm border border-[#B8D9B9] text-left hover:shadow-md transition-all"
            >
              <div className="flex items-start gap-4 mb-3">
                <div className="text-3xl">🙂🙂</div>
                <div className="flex-1">
                  <h3 className="text-[#2B2317] mb-2">Your week vs your Circle</h3>
                  <p className="text-sm text-[#4A7A4B]">
                    Your mornings were calmer than your Circle's average
                  </p>
                </div>
                <div className="text-2xl">🌱</div>
              </div>
              <div className="text-sm text-[#5D8A5E]">
                View comparison →
              </div>
            </button>

            {/* Logging Consistency Card */}
            <button
              onClick={() => setSelectedModal('loggingConsistency')}
              className="w-full bg-gradient-to-br from-[#FFF3EB] to-[#FFE8D9] rounded-3xl p-6 shadow-sm border border-[#F5D5C0] text-left hover:shadow-md transition-all"
            >
              <div className="flex items-start gap-4 mb-3">
                <div className="text-3xl">📊</div>
                <div className="flex-1">
                  <h3 className="text-[#2B2317] mb-2">Logging Consistency</h3>
                  <p className="text-sm text-[#8B6F5F]">
                    You logged 6 out of 7 days this week
                  </p>
                </div>
                <div className="text-2xl">✓</div>
              </div>
              <div className="text-sm text-[#D9532E]">
                Compare with Circle →
              </div>
            </button>

            {/* Circle Moments */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-[#3D2F24]">Moments from Your Circle</h3>
              </div>
              <div className="flex gap-3 overflow-x-auto pb-2 -mx-6 px-6 scrollbar-hide">
                {circleMoments.map((moment) => (
                  <MomentCard
                    key={moment.id}
                    moment={moment}
                    onReact={(type) => handleReact(moment.id, type)}
                  />
                ))}
              </div>
            </div>

            {/* Share Button */}
            <button
              onClick={() => setShowShareModal(true)}
              className="w-full py-4 bg-gradient-to-r from-[#E8734E] to-[#D9532E] text-white rounded-2xl shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2"
            >
              <Camera className="w-5 h-5" />
              <span>Share a Moment</span>
            </button>
          </div>
        )}

        {/* Everyone Tab */}
        {activeTab === 'everyone' && (
          <div className="px-6 pb-20 space-y-4">
            {/* Global Trend Card */}
            <div className="bg-gradient-to-br from-[#E8F3F8] to-[#C1DEE9] rounded-3xl p-6 shadow-sm border border-[#7BA8E8]">
              <div className="flex items-start gap-4 mb-3">
                <div className="w-12 h-12 rounded-full bg-white flex items-center justify-center flex-shrink-0">
                  <Globe className="w-6 h-6 text-[#5A8FD6]" />
                </div>
                <div>
                  <h3 className="text-[#2B2317] mb-2">Community Trend</h3>
                  <p className="text-sm text-[#4A5A6B]">
                    Most people are experiencing stable days this week
                  </p>
                </div>
              </div>
            </div>

            {/* Popular Patterns */}
            <div className="bg-white rounded-3xl p-6 shadow-sm border border-[#E5D5C5]">
              <h3 className="text-[#2B2317] mb-4">Popular Patterns</h3>
              <div className="space-y-3">
                <div className="flex items-center gap-3 p-4 bg-[#E8F3F8] rounded-2xl">
                  <span className="text-2xl">🌙</span>
                  <div className="flex-1">
                    <div className="text-sm text-[#2B2317]">Better sleep → calmer mornings</div>
                  </div>
                  <span className="text-xs text-[#9B8B7D]">78%</span>
                </div>
                <div className="flex items-center gap-3 p-4 bg-[#FFF3EB] rounded-2xl">
                  <span className="text-2xl">☕</span>
                  <div className="flex-1">
                    <div className="text-sm text-[#2B2317]">Coffee → earlier bowel movements</div>
                  </div>
                  <span className="text-xs text-[#9B8B7D]">65%</span>
                </div>
                <div className="flex items-center gap-3 p-4 bg-[#E5F4E6] rounded-2xl">
                  <span className="text-2xl">🍽️</span>
                  <div className="flex-1">
                    <div className="text-sm text-[#2B2317]">Late meals → tough evenings</div>
                  </div>
                  <span className="text-xs text-[#9B8B7D]">72%</span>
                </div>
              </div>
            </div>

            {/* Global Experiments */}
            <div className="bg-white rounded-3xl p-6 shadow-sm border border-[#E5D5C5]">
              <h3 className="text-[#2B2317] mb-4">People are trying...</h3>
              <div className="flex flex-wrap gap-2 mb-4">
                <div className="px-4 py-2 bg-[#E5F4E6] rounded-full text-sm text-[#5D8A5E] border border-[#B8D9B9]">
                  🧘 Morning meditation
                </div>
                <div className="px-4 py-2 bg-[#FFF3EB] rounded-full text-sm text-[#E8734E] border border-[#F5D5C0]">
                  🚫 Dairy-free diet
                </div>
                <div className="px-4 py-2 bg-[#E8F3F8] rounded-full text-sm text-[#5A8FD6] border border-[#C1DEE9]">
                  🏃 Daily walks
                </div>
                <div className="px-4 py-2 bg-[#F5E8FF] rounded-full text-sm text-[#9B5DE5] border border-[#E5D4F5]">
                  📝 Journaling
                </div>
              </div>
              <button className="text-sm text-[#D9532E] hover:underline">
                See how your Circle compares →
              </button>
            </div>

            {/* Community Moments */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-[#3D2F24]">Community Moments</h3>
              </div>
              <div className="flex gap-3 overflow-x-auto pb-2 -mx-6 px-6 scrollbar-hide">
                {everyoneMoments.map((moment) => (
                  <MomentCard
                    key={moment.id}
                    moment={moment}
                    onReact={(type) => handleReact(moment.id, type)}
                  />
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Modals */}
      <AnimatePresence>
        {showShareModal && <ShareMomentModal onClose={() => setShowShareModal(false)} />}
        {selectedModal === 'circleOverview' && <CircleOverviewModal onClose={() => setSelectedModal(null)} />}
        {selectedModal === 'sharedPattern' && <SharedPatternModal onClose={() => setSelectedModal(null)} />}
        {selectedModal === 'circleExperiments' && <CircleExperimentsModal onClose={() => setSelectedModal(null)} />}
        {selectedModal === 'weekComparison' && <WeekComparisonModal onClose={() => setSelectedModal(null)} />}
        {selectedModal === 'loggingConsistency' && <LoggingConsistencyModal onClose={() => setSelectedModal(null)} />}
      </AnimatePresence>
    </>
  );
}