import { Flame, Award, Heart, UserCircle } from 'lucide-react';

export function TopBar() {
  return (
    <div className="sticky top-0 z-10 bg-[#FBF7F4] px-6 py-4 flex justify-between items-center">
      <div className="flex items-center gap-4">
        <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white shadow-sm">
          <Flame className="w-4 h-4 text-[#D9532E]" />
          <span className="text-sm text-[#3D2F24]">3</span>
        </button>
        <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white shadow-sm">
          <Award className="w-4 h-4 text-[#5D8A5E]" />
          <span className="text-sm text-[#3D2F24]">12</span>
        </button>
        <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white shadow-sm">
          <Heart className="w-4 h-4 text-[#D9532E]" />
          <span className="text-sm text-[#3D2F24]">24</span>
        </button>
      </div>
      <button className="p-2 rounded-full hover:bg-white/50 transition-colors">
        <UserCircle className="w-7 h-7 text-[#7A6B5D]" />
      </button>
    </div>
  );
}