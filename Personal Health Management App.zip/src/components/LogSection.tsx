import { useState } from 'react';
import { 
  Plus, 
  Flame, 
  Heart, 
  Utensils, 
  Moon, 
  Calendar,
  X,
  Smile,
  Meh,
  Frown,
  Activity,
  MapPin,
  Pill,
  ChevronLeft,
  Award,
  Zap
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

type Category = 'feel' | 'ate' | 'activities' | 'events' | null;
type SymptomSeverity = 1 | 2 | 3 | 4 | 5;
type MoodType = 'great' | 'good' | 'neutral' | 'low' | 'bad';

interface LogEntry {
  category: string;
  type: string;
  value: string | number;
  timestamp: Date;
}

interface Medication {
  name: string;
  dosage: string;
  startDate: string;
  endDate: string;
}

// Dummy data for previous symptom logs
const previousSymptomLogs: Record<string, { severity: SymptomSeverity; date: string }> = {
  'Headache': { severity: 4, date: '2 days ago' },
  'Fatigue': { severity: 3, date: 'yesterday' },
  'Nausea': { severity: 2, date: '3 days ago' },
  'Pain': { severity: 5, date: 'yesterday' },
  'Bloating': { severity: 3, date: '4 days ago' },
  'Anxiety': { severity: 4, date: 'yesterday' }
};

// Track last log time (dummy data - in production this would come from backend)
let lastLogTime = new Date(Date.now() - 20 * 60 * 60 * 1000); // 20 hours ago
let currentStreak = 3;

function StreakCelebration({ onClose }: { onClose: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/40"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.8, opacity: 0 }}
        transition={{ type: 'spring', damping: 20, stiffness: 300 }}
        className="bg-white rounded-3xl p-8 shadow-2xl max-w-sm mx-4 text-center"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Animated Icon */}
        <motion.div
          animate={{ rotate: [0, -10, 10, -10, 10, 0] }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="mb-6"
        >
          <div className="w-24 h-24 mx-auto bg-gradient-to-br from-[#FFE8D9] to-[#FFD4B8] rounded-full flex items-center justify-center">
            <Flame className="w-12 h-12 text-[#D9532E]" />
          </div>
        </motion.div>

        {/* Confetti */}
        {[...Array(12)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ 
              x: 0, 
              y: 0, 
              scale: 0,
              rotate: 0 
            }}
            animate={{ 
              x: Math.cos(i * 30 * Math.PI / 180) * 150,
              y: Math.sin(i * 30 * Math.PI / 180) * 150,
              scale: [0, 1, 0.8],
              rotate: 360,
              opacity: [0, 1, 0]
            }}
            transition={{ 
              duration: 1,
              delay: 0.2,
              ease: "easeOut"
            }}
            className="absolute top-1/2 left-1/2 w-3 h-3 rounded-full"
            style={{
              backgroundColor: ['#FFE8D9', '#D4EDD5', '#E8F3F8', '#F5E8FF'][i % 4]
            }}
          />
        ))}

        <h2 className="text-[#2B2317] mb-2">Streak continued!</h2>
        <p className="text-[#6B5A4C] mb-6">
          You're on a <span className="text-[#D9532E]">{currentStreak}-day streak</span>! Keep it up!
        </p>

        <button
          onClick={onClose}
          className="px-8 py-3 rounded-2xl bg-gradient-to-br from-[#E8734E] to-[#D9532E] text-white shadow-lg hover:shadow-xl transition-all"
        >
          Awesome!
        </button>
      </motion.div>
    </motion.div>
  );
}

function CategoryButton({ 
  icon: Icon, 
  label, 
  bgColor, 
  iconColor,
  onClick 
}: { 
  icon: any; 
  label: string; 
  bgColor: string; 
  iconColor: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-4 p-5 rounded-2xl transition-all hover:scale-[1.02] active:scale-[0.98] text-left w-full shadow-sm"
      style={{ backgroundColor: bgColor }}
    >
      <div className="w-12 h-12 rounded-full bg-white flex items-center justify-center shadow-sm flex-shrink-0">
        <Icon className="w-6 h-6" style={{ color: iconColor }} />
      </div>
      <span className="text-[#2B2317]">{label}</span>
    </button>
  );
}

function WhatIFeelExpansion({ onClose, onLog }: { onClose: () => void; onLog: (data: any) => void }) {
  const [selectedSymptoms, setSelectedSymptoms] = useState<{ name: string; severity: SymptomSeverity }[]>([]);
  const [selectedMood, setSelectedMood] = useState<MoodType | null>(null);
  const [customSymptom, setCustomSymptom] = useState('');

  const commonSymptoms = [
    'Headache', 'Fatigue', 'Nausea', 'Pain', 'Bloating', 'Anxiety'
  ];

  const moods = [
    { type: 'great' as MoodType, icon: '😊', label: 'Great', color: '#5D8A5E' },
    { type: 'good' as MoodType, icon: '🙂', label: 'Good', color: '#7BA8E8' },
    { type: 'neutral' as MoodType, icon: '😐', label: 'Neutral', color: '#E8A33E' },
    { type: 'low' as MoodType, icon: '😕', label: 'Low', color: '#E8734E' },
    { type: 'bad' as MoodType, icon: '😞', label: 'Bad', color: '#D9532E' }
  ];

  const handleAddSymptom = (symptom: string) => {
    if (!selectedSymptoms.find(s => s.name === symptom)) {
      // Use previous severity as default if available, otherwise 3
      const previousLog = previousSymptomLogs[symptom];
      const defaultSeverity = previousLog ? previousLog.severity : 3;
      setSelectedSymptoms([...selectedSymptoms, { name: symptom, severity: defaultSeverity as SymptomSeverity }]);
    }
  };

  const handleUpdateSeverity = (symptom: string, severity: SymptomSeverity) => {
    setSelectedSymptoms(selectedSymptoms.map(s => 
      s.name === symptom ? { ...s, severity } : s
    ))
  };

  const handleLog = () => {
    onLog({ symptoms: selectedSymptoms, mood: selectedMood });
    onClose();
  };

  return (
    <motion.div
      initial={{ y: '100%' }}
      animate={{ y: 0 }}
      exit={{ y: '100%' }}
      transition={{ type: 'spring', damping: 30, stiffness: 300 }}
      className="fixed inset-0 z-50 bg-[#FBF7F4] overflow-y-auto"
    >
      {/* Header */}
      <div className="sticky top-0 bg-[#FBF7F4] border-b border-[#E5D5C5] px-6 py-4 flex items-center gap-3 z-10">
        <button onClick={onClose} className="p-2 hover:bg-white/50 rounded-full transition-colors">
          <ChevronLeft className="w-5 h-5 text-[#6B5A4C]" />
        </button>
        <div className="flex items-center gap-3 flex-1">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#FFE8E8] to-[#FFD4D4] flex items-center justify-center">
            <Heart className="w-5 h-5 text-[#D9532E]" />
          </div>
          <h2 className="text-[#2B2317]">What I Feel</h2>
        </div>
      </div>

      <div className="px-6 py-6 pb-32">
        {/* Mood Section */}
        <div className="mb-6">
          <h3 className="text-[#3D2F24] mb-3">How's your mood?</h3>
          <div className="grid grid-cols-5 gap-2">
            {moods.map((mood) => (
              <button
                key={mood.type}
                onClick={() => setSelectedMood(mood.type)}
                className={`flex flex-col items-center gap-2 p-3 rounded-2xl transition-all ${
                  selectedMood === mood.type
                    ? 'bg-white shadow-md scale-105'
                    : 'bg-white/50 hover:bg-white/80'
                }`}
                style={{
                  borderWidth: selectedMood === mood.type ? '2px' : '1px',
                  borderColor: selectedMood === mood.type ? mood.color : '#E5D5C5'
                }}
              >
                <span className="text-2xl">{mood.icon}</span>
                <span className="text-xs text-[#6B5A4C]">{mood.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Symptoms Section */}
        <div className="mb-6">
          <h3 className="text-[#3D2F24] mb-3">Any symptoms?</h3>
          <div className="flex flex-wrap gap-2 mb-4">
            {commonSymptoms.map((symptom) => (
              <button
                key={symptom}
                onClick={() => handleAddSymptom(symptom)}
                disabled={selectedSymptoms.some(s => s.name === symptom)}
                className={`px-4 py-2 rounded-full text-sm transition-all ${
                  selectedSymptoms.some(s => s.name === symptom)
                    ? 'bg-[#D4EDD5] text-[#5D8A5E] border-[#B8D9B9]'
                    : 'bg-white text-[#6B5A4C] border-[#E5D5C5] hover:border-[#D9532E]'
                } border`}
              >
                {symptom}
              </button>
            ))}
          </div>

          {/* Custom symptom input */}
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Add custom symptom..."
              value={customSymptom}
              onChange={(e) => setCustomSymptom(e.target.value)}
              className="flex-1 px-4 py-3 rounded-2xl bg-white border border-[#E5D5C5] text-[#2B2317] placeholder:text-[#9B8B7D] focus:outline-none focus:ring-2 focus:ring-[#D9532E]/20"
            />
            <button
              onClick={() => {
                if (customSymptom.trim()) {
                  handleAddSymptom(customSymptom);
                  setCustomSymptom('');
                }
              }}
              className="px-5 py-3 rounded-2xl bg-[#D9532E] text-white hover:bg-[#C4461A] transition-colors"
            >
              Add
            </button>
          </div>
        </div>

        {/* Selected Symptoms with Severity */}
        {selectedSymptoms.length > 0 && (
          <div className="space-y-4">
            <h3 className="text-[#3D2F24]">Rate severity</h3>
            {selectedSymptoms.map((symptom) => {
              const previousLog = previousSymptomLogs[symptom.name];
              return (
                <div key={symptom.name} className="bg-white rounded-2xl p-5 border border-[#E5D5C5]">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[#2B2317]">{symptom.name}</span>
                    <button
                      onClick={() => setSelectedSymptoms(selectedSymptoms.filter(s => s.name !== symptom.name))}
                      className="text-[#9B8B7D] hover:text-[#D9532E]"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                  
                  {/* Previous log reminder */}
                  {previousLog && (
                    <div className="mb-3 px-3 py-2 rounded-xl bg-[#F5E5D5] border border-[#E5D5C5]">
                      <p className="text-xs text-[#6B5A4C]">
                        Last time ({previousLog.date}): <span className="text-[#D9532E]">Level {previousLog.severity}</span>
                      </p>
                    </div>
                  )}

                  <div className="flex gap-2">
                    {[1, 2, 3, 4, 5].map((level) => (
                      <button
                        key={level}
                        onClick={() => handleUpdateSeverity(symptom.name, level as SymptomSeverity)}
                        className={`flex-1 h-10 rounded-xl transition-all ${
                          symptom.severity === level
                            ? 'bg-gradient-to-br from-[#E8734E] to-[#D9532E] text-white shadow-md'
                            : 'bg-[#F5E5D5] text-[#6B5A4C] hover:bg-[#EBDAC5]'
                        }`}
                      >
                        {level}
                      </button>
                    ))}
                  </div>
                  <div className="flex justify-between mt-2 text-xs text-[#9B8B7D] px-1">
                    <span>Mild</span>
                    <span>Severe</span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Bottom Log Button */}
      <div className="fixed bottom-0 left-0 right-0 bg-gradient-to-t from-[#FBF7F4] via-[#FBF7F4] to-transparent px-6 py-6">
        <button
          onClick={handleLog}
          disabled={!selectedMood && selectedSymptoms.length === 0}
          className="w-full py-4 rounded-2xl bg-gradient-to-br from-[#E8734E] to-[#D9532E] text-white shadow-lg hover:shadow-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Log this
        </button>
      </div>
    </motion.div>
  );
}

function WhatIAteExpansion({ onClose, onLog }: { onClose: () => void; onLog: (data: any) => void }) {
  const [foods, setFoods] = useState<string[]>([]);
  const [medications, setMedications] = useState<Medication[]>([]);
  const [foodInput, setFoodInput] = useState('');
  const [showMedicationForm, setShowMedicationForm] = useState(false);
  const [medicationForm, setMedicationForm] = useState<Medication>({
    name: '',
    dosage: '',
    startDate: new Date().toISOString().split('T')[0],
    endDate: ''
  });

  const commonFoods = [
    '☕ Coffee', '🥛 Dairy', '🍞 Bread', '🥗 Salad', '🍎 Fruit', '🥜 Nuts'
  ];

  const handleAddMedication = () => {
    if (medicationForm.name.trim()) {
      setMedications([...medications, medicationForm]);
      setMedicationForm({
        name: '',
        dosage: '',
        startDate: new Date().toISOString().split('T')[0],
        endDate: ''
      });
      setShowMedicationForm(false);
    }
  };

  const handleLog = () => {
    onLog({ foods, medications });
    onClose();
  };

  return (
    <motion.div
      initial={{ y: '100%' }}
      animate={{ y: 0 }}
      exit={{ y: '100%' }}
      transition={{ type: 'spring', damping: 30, stiffness: 300 }}
      className="fixed inset-0 z-50 bg-[#FBF7F4] overflow-y-auto"
    >
      {/* Header */}
      <div className="sticky top-0 bg-[#FBF7F4] border-b border-[#E5D5C5] px-6 py-4 flex items-center gap-3 z-10">
        <button onClick={onClose} className="p-2 hover:bg-white/50 rounded-full transition-colors">
          <ChevronLeft className="w-5 h-5 text-[#6B5A4C]" />
        </button>
        <div className="flex items-center gap-3 flex-1">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#FFF3EB] to-[#FFE8D9] flex items-center justify-center">
            <Utensils className="w-5 h-5 text-[#D9532E]" />
          </div>
          <h2 className="text-[#2B2317]">What I Ate</h2>
        </div>
      </div>

      <div className="px-6 py-6 pb-32">
        {/* Food Section */}
        <div className="mb-8">
          <h3 className="text-[#3D2F24] mb-3">Food & Drinks</h3>
          
          {/* Quick add */}
          <div className="grid grid-cols-3 gap-2 mb-4">
            {commonFoods.map((food) => (
              <button
                key={food}
                onClick={() => setFoods([...foods, food])}
                className="p-3 rounded-2xl bg-white border border-[#E5D5C5] text-sm hover:border-[#D9532E] transition-all"
              >
                {food}
              </button>
            ))}
          </div>

          {/* Custom food input */}
          <div className="flex gap-2 mb-4">
            <input
              type="text"
              placeholder="Add food or drink..."
              value={foodInput}
              onChange={(e) => setFoodInput(e.target.value)}
              className="flex-1 px-4 py-3 rounded-2xl bg-white border border-[#E5D5C5] text-[#2B2317] placeholder:text-[#9B8B7D] focus:outline-none focus:ring-2 focus:ring-[#D9532E]/20"
            />
            <button
              onClick={() => {
                if (foodInput.trim()) {
                  setFoods([...foods, foodInput]);
                  setFoodInput('');
                }
              }}
              className="px-5 py-3 rounded-2xl bg-[#D9532E] text-white hover:bg-[#C4461A] transition-colors"
            >
              Add
            </button>
          </div>

          {/* Added foods */}
          {foods.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {foods.map((food, index) => (
                <div
                  key={index}
                  className="flex items-center gap-2 px-4 py-2 rounded-full bg-[#D4EDD5] text-[#5D8A5E] border border-[#B8D9B9]"
                >
                  <span className="text-sm">{food}</span>
                  <button
                    onClick={() => setFoods(foods.filter((_, i) => i !== index))}
                    className="hover:text-[#D9532E]"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Medication Section */}
        <div>
          <h3 className="text-[#3D2F24] mb-3">Medication</h3>
          
          {!showMedicationForm ? (
            <button
              onClick={() => setShowMedicationForm(true)}
              className="w-full p-5 rounded-2xl bg-white border border-[#E5D5C5] hover:border-[#D9532E] transition-all flex items-center justify-center gap-2 text-[#6B5A4C] hover:text-[#D9532E]"
            >
              <Pill className="w-5 h-5" />
              <span>Add medication</span>
            </button>
          ) : (
            <div className="bg-white rounded-2xl p-5 border border-[#E5D5C5] space-y-4 mb-4">
              <div>
                <label className="block text-sm text-[#6B5A4C] mb-2">Medication name *</label>
                <input
                  type="text"
                  value={medicationForm.name}
                  onChange={(e) => setMedicationForm({ ...medicationForm, name: e.target.value })}
                  placeholder="e.g., Aspirin"
                  className="w-full px-4 py-3 rounded-2xl bg-[#FBF7F4] border border-[#E5D5C5] text-[#2B2317] placeholder:text-[#9B8B7D] focus:outline-none focus:ring-2 focus:ring-[#D9532E]/20"
                />
              </div>
              <div>
                <label className="block text-sm text-[#6B5A4C] mb-2">Dosage</label>
                <input
                  type="text"
                  value={medicationForm.dosage}
                  onChange={(e) => setMedicationForm({ ...medicationForm, dosage: e.target.value })}
                  placeholder="e.g., 100mg, 1 tablet"
                  className="w-full px-4 py-3 rounded-2xl bg-[#FBF7F4] border border-[#E5D5C5] text-[#2B2317] placeholder:text-[#9B8B7D] focus:outline-none focus:ring-2 focus:ring-[#D9532E]/20"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm text-[#6B5A4C] mb-2">Start date</label>
                  <input
                    type="date"
                    value={medicationForm.startDate}
                    onChange={(e) => setMedicationForm({ ...medicationForm, startDate: e.target.value })}
                    className="w-full px-4 py-3 rounded-2xl bg-[#FBF7F4] border border-[#E5D5C5] text-[#2B2317] focus:outline-none focus:ring-2 focus:ring-[#D9532E]/20"
                  />
                </div>
                <div>
                  <label className="block text-sm text-[#6B5A4C] mb-2">End date (optional)</label>
                  <input
                    type="date"
                    value={medicationForm.endDate}
                    onChange={(e) => setMedicationForm({ ...medicationForm, endDate: e.target.value })}
                    className="w-full px-4 py-3 rounded-2xl bg-[#FBF7F4] border border-[#E5D5C5] text-[#2B2317] focus:outline-none focus:ring-2 focus:ring-[#D9532E]/20"
                  />
                </div>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => {
                    setShowMedicationForm(false);
                    setMedicationForm({
                      name: '',
                      dosage: '',
                      startDate: new Date().toISOString().split('T')[0],
                      endDate: ''
                    });
                  }}
                  className="flex-1 px-4 py-3 rounded-2xl bg-[#F5E5D5] text-[#6B5A4C] hover:bg-[#EBDAC5] transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleAddMedication}
                  disabled={!medicationForm.name.trim()}
                  className="flex-1 px-4 py-3 rounded-2xl bg-[#D9532E] text-white hover:bg-[#C4461A] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Add
                </button>
              </div>
            </div>
          )}

          {medications.length > 0 && (
            <div className="space-y-2 mt-3">
              {medications.map((med, index) => (
                <div
                  key={index}
                  className="px-5 py-4 rounded-2xl bg-white border border-[#E5D5C5]"
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <Pill className="w-4 h-4 text-[#D9532E] flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-[#2B2317]">{med.name}</p>
                        {med.dosage && (
                          <p className="text-sm text-[#6B5A4C]">{med.dosage}</p>
                        )}
                        <p className="text-xs text-[#9B8B7D] mt-1">
                          {med.startDate}{med.endDate ? ` - ${med.endDate}` : ' (ongoing)'}
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={() => setMedications(medications.filter((_, i) => i !== index))}
                      className="text-[#9B8B7D] hover:text-[#D9532E]"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Bottom Log Button */}
      <div className="fixed bottom-0 left-0 right-0 bg-gradient-to-t from-[#FBF7F4] via-[#FBF7F4] to-transparent px-6 py-6">
        <button
          onClick={handleLog}
          disabled={foods.length === 0 && medications.length === 0}
          className="w-full py-4 rounded-2xl bg-gradient-to-br from-[#E8734E] to-[#D9532E] text-white shadow-lg hover:shadow-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Log this
        </button>
      </div>
    </motion.div>
  );
}

function MyActivitiesExpansion({ onClose, onLog }: { onClose: () => void; onLog: (data: any) => void }) {
  const [exercise, setExercise] = useState<{ type: string; duration: number; intensity: number } | null>(null);
  const [sleep, setSleep] = useState<{ hours: number; quality: number } | null>(null);

  const exerciseTypes = ['🏃 Running', '🚴 Cycling', '🏋️ Gym', '🧘 Yoga', '🚶 Walking', '🏊 Swimming'];

  const handleLog = () => {
    onLog({ exercise, sleep });
    onClose();
  };

  return (
    <motion.div
      initial={{ y: '100%' }}
      animate={{ y: 0 }}
      exit={{ y: '100%' }}
      transition={{ type: 'spring', damping: 30, stiffness: 300 }}
      className="fixed inset-0 z-50 bg-[#FBF7F4] overflow-y-auto"
    >
      {/* Header */}
      <div className="sticky top-0 bg-[#FBF7F4] border-b border-[#E5D5C5] px-6 py-4 flex items-center gap-3 z-10">
        <button onClick={onClose} className="p-2 hover:bg-white/50 rounded-full transition-colors">
          <ChevronLeft className="w-5 h-5 text-[#6B5A4C]" />
        </button>
        <div className="flex items-center gap-3 flex-1">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#E5F4E6] to-[#D4EDD5] flex items-center justify-center">
            <Activity className="w-5 h-5 text-[#5D8A5E]" />
          </div>
          <h2 className="text-[#2B2317]">My Activities</h2>
        </div>
      </div>

      <div className="px-6 py-6 pb-32">
        {/* Exercise Section */}
        <div className="mb-8">
          <h3 className="text-[#3D2F24] mb-3">Exercise</h3>
          
          <div className="grid grid-cols-3 gap-2 mb-4">
            {exerciseTypes.map((type) => (
              <button
                key={type}
                onClick={() => setExercise({ type, duration: 30, intensity: 3 })}
                className={`p-3 rounded-2xl border text-sm transition-all ${
                  exercise?.type === type
                    ? 'bg-[#D4EDD5] border-[#B8D9B9] text-[#5D8A5E]'
                    : 'bg-white border-[#E5D5C5] hover:border-[#5D8A5E]'
                }`}
              >
                {type}
              </button>
            ))}
          </div>

          {exercise && (
            <div className="bg-white rounded-2xl p-5 border border-[#E5D5C5] space-y-5">
              {/* Duration */}
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-sm text-[#6B5A4C]">Duration</span>
                  <span className="text-sm text-[#2B2317]">{exercise.duration} min</span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="120"
                  step="5"
                  value={exercise.duration}
                  onChange={(e) => setExercise({ ...exercise, duration: parseInt(e.target.value) })}
                  className="w-full h-2 bg-[#F5E5D5] rounded-full appearance-none cursor-pointer"
                  style={{
                    background: `linear-gradient(to right, #5D8A5E 0%, #5D8A5E ${(exercise.duration / 120) * 100}%, #F5E5D5 ${(exercise.duration / 120) * 100}%, #F5E5D5 100%)`
                  }}
                />
              </div>

              {/* Intensity */}
              <div>
                <div className="flex justify-between mb-3">
                  <span className="text-sm text-[#6B5A4C]">Intensity</span>
                </div>
                <div className="flex gap-2">
                  {[1, 2, 3, 4, 5].map((level) => (
                    <button
                      key={level}
                      onClick={() => setExercise({ ...exercise, intensity: level })}
                      className={`flex-1 h-10 rounded-xl transition-all ${
                        exercise.intensity === level
                          ? 'bg-gradient-to-br from-[#7BA8E8] to-[#5A8FD6] text-white shadow-md'
                          : 'bg-[#F5E5D5] text-[#6B5A4C] hover:bg-[#EBDAC5]'
                      }`}
                    >
                      {level}
                    </button>
                  ))}
                </div>
                <div className="flex justify-between mt-2 text-xs text-[#9B8B7D]">
                  <span>Light</span>
                  <span>Intense</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Sleep Section */}
        <div>
          <h3 className="text-[#3D2F24] mb-3">Sleep</h3>
          
          <button
            onClick={() => setSleep({ hours: 7, quality: 3 })}
            className={`w-full p-5 rounded-2xl border text-left transition-all ${
              sleep
                ? 'bg-[#E8F3F8] border-[#C1DEE9]'
                : 'bg-white border-[#E5D5C5] hover:border-[#7BA8E8]'
            }`}
          >
            <div className="flex items-center gap-3 mb-1">
              <Moon className="w-5 h-5 text-[#5A8FD6]" />
              <span className="text-[#2B2317]">Log sleep</span>
            </div>
            <p className="text-sm text-[#6B5A4C] ml-8">Track last night's sleep</p>
          </button>

          {sleep && (
            <div className="bg-white rounded-2xl p-5 border border-[#E5D5C5] mt-3 space-y-5">
              {/* Hours */}
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-sm text-[#6B5A4C]">Hours slept</span>
                  <span className="text-sm text-[#2B2317]">{sleep.hours}h</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="12"
                  step="0.5"
                  value={sleep.hours}
                  onChange={(e) => setSleep({ ...sleep, hours: parseFloat(e.target.value) })}
                  className="w-full h-2 bg-[#F5E5D5] rounded-full appearance-none cursor-pointer"
                  style={{
                    background: `linear-gradient(to right, #7BA8E8 0%, #7BA8E8 ${(sleep.hours / 12) * 100}%, #F5E5D5 ${(sleep.hours / 12) * 100}%, #F5E5D5 100%)`
                  }}
                />
              </div>

              {/* Quality */}
              <div>
                <div className="flex justify-between mb-3">
                  <span className="text-sm text-[#6B5A4C]">Sleep quality</span>
                </div>
                <div className="flex gap-2">
                  {[1, 2, 3, 4, 5].map((level) => (
                    <button
                      key={level}
                      onClick={() => setSleep({ ...sleep, quality: level })}
                      className={`flex-1 h-10 rounded-xl transition-all ${
                        sleep.quality === level
                          ? 'bg-gradient-to-br from-[#7BA8E8] to-[#5A8FD6] text-white shadow-md'
                          : 'bg-[#F5E5D5] text-[#6B5A4C] hover:bg-[#EBDAC5]'
                      }`}
                    >
                      {level}
                    </button>
                  ))}
                </div>
                <div className="flex justify-between mt-2 text-xs text-[#9B8B7D]">
                  <span>Poor</span>
                  <span>Great</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Bottom Log Button */}
      <div className="fixed bottom-0 left-0 right-0 bg-gradient-to-t from-[#FBF7F4] via-[#FBF7F4] to-transparent px-6 py-6">
        <button
          onClick={handleLog}
          disabled={!exercise && !sleep}
          className="w-full py-4 rounded-2xl bg-gradient-to-br from-[#E8734E] to-[#D9532E] text-white shadow-lg hover:shadow-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Log this
        </button>
      </div>
    </motion.div>
  );
}

function MyEventsExpansion({ onClose, onLog }: { onClose: () => void; onLog: (data: any) => void }) {
  const [doctorVisit, setDoctorVisit] = useState<{ type: string; date: string; notes: string } | null>(null);
  const [locationChange, setLocationChange] = useState<{ location: string; date: string; reason: string } | null>(null);

  const visitTypes = ['🩺 Check-up', '💊 Specialist', '🏥 Procedure', '💉 Vaccination'];

  const handleLog = () => {
    onLog({ doctorVisit, locationChange });
    onClose();
  };

  return (
    <motion.div
      initial={{ y: '100%' }}
      animate={{ y: 0 }}
      exit={{ y: '100%' }}
      transition={{ type: 'spring', damping: 30, stiffness: 300 }}
      className="fixed inset-0 z-50 bg-[#FBF7F4] overflow-y-auto"
    >
      {/* Header */}
      <div className="sticky top-0 bg-[#FBF7F4] border-b border-[#E5D5C5] px-6 py-4 flex items-center gap-3 z-10">
        <button onClick={onClose} className="p-2 hover:bg-white/50 rounded-full transition-colors">
          <ChevronLeft className="w-5 h-5 text-[#6B5A4C]" />
        </button>
        <div className="flex items-center gap-3 flex-1">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#F5E8FF] to-[#EDD4FF] flex items-center justify-center">
            <Calendar className="w-5 h-5 text-[#9B5DE5]" />
          </div>
          <h2 className="text-[#2B2317]">My Events</h2>
        </div>
      </div>

      <div className="px-6 py-6 pb-32">
        {/* Doctor Visit Section */}
        <div className="mb-8">
          <h3 className="text-[#3D2F24] mb-3">Doctor Visit</h3>
          
          <div className="grid grid-cols-2 gap-2 mb-4">
            {visitTypes.map((type) => (
              <button
                key={type}
                onClick={() => setDoctorVisit({ type, date: new Date().toISOString().split('T')[0], notes: '' })}
                className={`p-3 rounded-2xl border text-sm transition-all ${
                  doctorVisit?.type === type
                    ? 'bg-[#F5E8FF] border-[#E5D4F5] text-[#9B5DE5]'
                    : 'bg-white border-[#E5D5C5] hover:border-[#9B5DE5]'
                }`}
              >
                {type}
              </button>
            ))}
          </div>

          {doctorVisit && (
            <div className="bg-white rounded-2xl p-5 border border-[#E5D5C5] space-y-4">
              <div>
                <label className="block text-sm text-[#6B5A4C] mb-2">Date</label>
                <input
                  type="date"
                  value={doctorVisit.date}
                  onChange={(e) => setDoctorVisit({ ...doctorVisit, date: e.target.value })}
                  className="w-full px-4 py-3 rounded-2xl bg-[#FBF7F4] border border-[#E5D5C5] text-[#2B2317] focus:outline-none focus:ring-2 focus:ring-[#9B5DE5]/20"
                />
              </div>
              <div>
                <label className="block text-sm text-[#6B5A4C] mb-2">Notes (optional)</label>
                <textarea
                  value={doctorVisit.notes}
                  onChange={(e) => setDoctorVisit({ ...doctorVisit, notes: e.target.value })}
                  placeholder="Any important details..."
                  className="w-full px-4 py-3 rounded-2xl bg-[#FBF7F4] border border-[#E5D5C5] text-[#2B2317] placeholder:text-[#9B8B7D] focus:outline-none focus:ring-2 focus:ring-[#9B5DE5]/20 resize-none"
                  rows={3}
                />
              </div>
            </div>
          )}
        </div>

        {/* Location Change Section */}
        <div>
          <h3 className="text-[#3D2F24] mb-3">Location Change</h3>
          
          <button
            onClick={() => setLocationChange({ location: '', date: new Date().toISOString().split('T')[0], reason: '' })}
            className={`w-full p-5 rounded-2xl border text-left transition-all ${
              locationChange
                ? 'bg-[#FFF9E6] border-[#F5E5B8]'
                : 'bg-white border-[#E5D5C5] hover:border-[#E8A33E]'
            }`}
          >
            <div className="flex items-center gap-3 mb-1">
              <MapPin className="w-5 h-5 text-[#E8A33E]" />
              <span className="text-[#2B2317]">Log location change</span>
            </div>
            <p className="text-sm text-[#6B5A4C] ml-8">Travel, move, or environment change</p>
          </button>

          {locationChange && (
            <div className="bg-white rounded-2xl p-5 border border-[#E5D5C5] mt-3 space-y-4">
              <div>
                <label className="block text-sm text-[#6B5A4C] mb-2">Date</label>
                <input
                  type="date"
                  value={locationChange.date}
                  onChange={(e) => setLocationChange({ ...locationChange, date: e.target.value })}
                  className="w-full px-4 py-3 rounded-2xl bg-[#FBF7F4] border border-[#E5D5C5] text-[#2B2317] focus:outline-none focus:ring-2 focus:ring-[#E8A33E]/20"
                />
              </div>
              <div>
                <label className="block text-sm text-[#6B5A4C] mb-2">Location</label>
                <input
                  type="text"
                  value={locationChange.location}
                  onChange={(e) => setLocationChange({ ...locationChange, location: e.target.value })}
                  placeholder="Where are you?"
                  className="w-full px-4 py-3 rounded-2xl bg-[#FBF7F4] border border-[#E5D5C5] text-[#2B2317] placeholder:text-[#9B8B7D] focus:outline-none focus:ring-2 focus:ring-[#E8A33E]/20"
                />
              </div>
              <div>
                <label className="block text-sm text-[#6B5A4C] mb-2">Reason</label>
                <input
                  type="text"
                  value={locationChange.reason}
                  onChange={(e) => setLocationChange({ ...locationChange, reason: e.target.value })}
                  placeholder="Travel, relocation, etc."
                  className="w-full px-4 py-3 rounded-2xl bg-[#FBF7F4] border border-[#E5D5C5] text-[#2B2317] placeholder:text-[#9B8B7D] focus:outline-none focus:ring-2 focus:ring-[#E8A33E]/20"
                />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Bottom Log Button */}
      <div className="fixed bottom-0 left-0 right-0 bg-gradient-to-t from-[#FBF7F4] via-[#FBF7F4] to-transparent px-6 py-6">
        <button
          onClick={handleLog}
          disabled={!doctorVisit && !locationChange}
          className="w-full py-4 rounded-2xl bg-gradient-to-br from-[#E8734E] to-[#D9532E] text-white shadow-lg hover:shadow-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Log this
        </button>
      </div>
    </motion.div>
  );
}

export function LogSection() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<Category>(null);
  const [isStreakCelebrationOpen, setIsStreakCelebrationOpen] = useState(false);

  const handleCategorySelect = (category: Category) => {
    setSelectedCategory(category);
  };

  const handleLog = (data: any) => {
    console.log('Logged:', data);
    // Here you would save the data
    setIsModalOpen(false);
    setSelectedCategory(null);

    // Check if the log is within 24 hours of the last log
    const now = new Date();
    if (now.getTime() - lastLogTime.getTime() < 24 * 60 * 60 * 1000) {
      currentStreak++;
      setIsStreakCelebrationOpen(true);
    } else {
      currentStreak = 1;
    }
    lastLogTime = now;
  };

  const handleCloseExpansion = () => {
    setSelectedCategory(null);
  };

  return (
    <>
      <section className="px-6 py-4">
        <div className="bg-gradient-to-br from-[#FFF3EB] to-[#FFE8D9] rounded-3xl p-6 shadow-sm border border-[#F5D5C0]">
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1">
              <h2 className="text-[#3D2F24] mb-2">Log your day</h2>
              <p className="text-sm text-[#8B6F5F] mb-3">
                How are you feeling today?
              </p>
              <div className="flex items-center gap-2">
                <Flame className="w-5 h-5 text-[#D9532E]" />
                <span className="text-[#3D2F24]">3-day streak</span>
              </div>
            </div>
            <button 
              onClick={() => setIsModalOpen(true)}
              className="flex-shrink-0 w-16 h-16 rounded-full bg-white shadow-lg flex items-center justify-center hover:shadow-xl transition-all hover:scale-105 border-2 border-[#D9532E]"
            >
              <Plus className="w-8 h-8 text-[#D9532E] stroke-[3]" />
            </button>
          </div>
        </div>
      </section>

      {/* Pull-up Modal */}
      <AnimatePresence>
        {isModalOpen && !selectedCategory && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-40 bg-black/20"
            onClick={() => setIsModalOpen(false)}
          >
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 30, stiffness: 300 }}
              onClick={(e) => e.stopPropagation()}
              className="fixed bottom-0 left-0 right-0 bg-[#FBF7F4] rounded-t-[32px] shadow-2xl max-w-md mx-auto"
            >
              {/* Drag handle */}
              <div className="flex justify-center pt-3 pb-2">
                <div className="w-12 h-1.5 bg-[#D5C5B5] rounded-full"></div>
              </div>

              <div className="px-6 pb-8 pt-2">
                <h2 className="text-[#2B2317] mb-6 text-center">What would you like to log?</h2>

                <div className="space-y-3">
                  <CategoryButton
                    icon={Heart}
                    label="What I Feel"
                    bgColor="#FFE8E8"
                    iconColor="#D9532E"
                    onClick={() => handleCategorySelect('feel')}
                  />
                  <CategoryButton
                    icon={Utensils}
                    label="What I Ate"
                    bgColor="#FFF3EB"
                    iconColor="#E8734E"
                    onClick={() => handleCategorySelect('ate')}
                  />
                  <CategoryButton
                    icon={Moon}
                    label="My Activities"
                    bgColor="#E5F4E6"
                    iconColor="#5D8A5E"
                    onClick={() => handleCategorySelect('activities')}
                  />
                  <CategoryButton
                    icon={Calendar}
                    label="My Events"
                    bgColor="#F5E8FF"
                    iconColor="#9B5DE5"
                    onClick={() => handleCategorySelect('events')}
                  />
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}

        {/* Category Expansions */}
        {selectedCategory === 'feel' && (
          <WhatIFeelExpansion onClose={handleCloseExpansion} onLog={handleLog} />
        )}
        {selectedCategory === 'ate' && (
          <WhatIAteExpansion onClose={handleCloseExpansion} onLog={handleLog} />
        )}
        {selectedCategory === 'activities' && (
          <MyActivitiesExpansion onClose={handleCloseExpansion} onLog={handleLog} />
        )}
        {selectedCategory === 'events' && (
          <MyEventsExpansion onClose={handleCloseExpansion} onLog={handleLog} />
        )}
      </AnimatePresence>

      {/* Streak Celebration */}
      <AnimatePresence>
        {isStreakCelebrationOpen && (
          <StreakCelebration onClose={() => setIsStreakCelebrationOpen(false)} />
        )}
      </AnimatePresence>
    </>
  );
}