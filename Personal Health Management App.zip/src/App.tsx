import { useState } from 'react';
import { MeScreen } from './components/MeScreen';
import { CommunityScreen } from './components/CommunityScreen';
import { User, Users } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'me' | 'community'>('me');

  return (
    <div className="min-h-screen bg-[#FBF7F4] flex flex-col max-w-md mx-auto">
      {/* Main Content */}
      <div className="flex-1 overflow-y-auto pb-20">
        {activeTab === 'me' ? (
          <MeScreen onNavigateToCommunity={() => setActiveTab('community')} />
        ) : (
          <CommunityScreen />
        )}
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white border-t border-[#E5D5C5] px-6 py-3">
        <div className="flex justify-around items-center">
          <button
            onClick={() => setActiveTab('me')}
            className={`flex flex-col items-center gap-1 py-2 px-6 rounded-2xl transition-all ${
              activeTab === 'me'
                ? 'text-[#D9532E]'
                : 'text-[#7A6B5D]'
            }`}
          >
            <User className={`w-6 h-6 ${activeTab === 'me' ? 'stroke-[2.5]' : 'stroke-2'}`} />
            <span className="text-xs">Me</span>
          </button>
          <button
            onClick={() => setActiveTab('community')}
            className={`flex flex-col items-center gap-1 py-2 px-6 rounded-2xl transition-all ${
              activeTab === 'community'
                ? 'text-[#D9532E]'
                : 'text-[#7A6B5D]'
            }`}
          >
            <Users className={`w-6 h-6 ${activeTab === 'community' ? 'stroke-[2.5]' : 'stroke-2'}`} />
            <span className="text-xs">Community</span>
          </button>
        </div>
      </div>
    </div>
  );
}