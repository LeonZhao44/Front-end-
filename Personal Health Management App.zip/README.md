
  # Personal Health Management App

  This is a code bundle for Personal Health Management App. The original project is available at https://www.figma.com/design/vsKPcp78FoL04jOLFil7Gj/Personal-Health-Management-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  